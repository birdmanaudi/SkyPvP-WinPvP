package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class SetRankCommand implements CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;

    public SetRankCommand(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.isOp() && !sender.hasPermission("skypvp.setrank")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }

        RankManager ranks = plugin.ranks();
        String list = ranks.allRanks().stream().map(RankManager.Rank::id).collect(Collectors.joining(", "));

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            ranks.loadRanks();
            for (Player p : Bukkit.getOnlinePlayers()) ranks.apply(p);
            plugin.sidebar().reloadAll();
            plugin.chat().reload();
            plugin.holograms().refreshAll();
            sender.sendMessage(plugin.msg("reloaded"));
            return true;
        }

        if (args.length < 2 || args.length > 3) {
            sender.sendMessage(plugin.msg("usage-setrank"));
            sender.sendMessage(plugin.msg("rank-list", "{ranks}", list));
            return true;
        }

        RankManager.Rank rank = ranks.byId(args[1]);
        if (rank == null) {
            sender.sendMessage(plugin.msg("rank-unknown", "{rank}", args[1]));
            sender.sendMessage(plugin.msg("rank-list", "{ranks}", list));
            return true;
        }

        long duration = TimeUtil.PERM;
        if (args.length == 3) {
            duration = TimeUtil.parse(args[2]);
            if (duration == TimeUtil.INVALID) {
                sender.sendMessage(plugin.msg("invalid-duration"));
                return true;
            }
        }

        OfflinePlayer target = Bukkit.getPlayerExact(args[0]);
        if (target == null) target = Bukkit.getOfflinePlayerIfCached(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
            return true;
        }

        ranks.setRank(target, rank, duration);
        String name = target.getName() != null ? target.getName() : args[0];
        String dur = duration > 0 ? " &7für &f" + TimeUtil.format(duration) : "";
        sender.sendMessage(plugin.msg("rank-set", "{player}", name, "{rank}", rank.displayName(), "{duration}", dur));

        Player online = target.getPlayer();
        if (online != null && !online.equals(sender)) {
            online.sendMessage(plugin.msg("rank-received", "{rank}", rank.displayName(), "{duration}", dur));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
            }
            if ("reload".startsWith(start)) out.add("reload");
        } else if (args.length == 2) {
            for (RankManager.Rank r : plugin.ranks().allRanks()) {
                if (r.id().startsWith(start)) out.add(r.id());
            }
        } else if (args.length == 3) {
            for (String s : List.of("30d", "90d", "perm")) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }
}
