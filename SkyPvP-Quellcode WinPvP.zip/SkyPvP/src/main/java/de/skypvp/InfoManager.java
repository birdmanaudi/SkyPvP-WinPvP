package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Info-Befehle (/regeln, /discord, /vote, /website – Texte in info.* der config.yml)
 * und Vote-Belohnung. Votes kommen automatisch von NuVotifier (falls installiert)
 * oder per Konsole/Vote-Plugin: /votereward <Spieler>
 */
public class InfoManager implements CommandExecutor, Listener {

    private final SkyPvPPlugin plugin;
    private final File file;
    private final YamlConfiguration data;

    public InfoManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "votes.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
        hookVotifier();
    }

    @SuppressWarnings("unchecked")
    private void hookVotifier() {
        try {
            Class<? extends Event> clazz = (Class<? extends Event>) Class.forName("com.vexsoftware.votifier.model.VotifierEvent");
            Bukkit.getPluginManager().registerEvent(clazz, this, EventPriority.NORMAL, (listener, event) -> {
                try {
                    Object vote = event.getClass().getMethod("getVote").invoke(event);
                    Object name = vote.getClass().getMethod("getUsername").invoke(vote);
                    Bukkit.getScheduler().runTask(plugin, () -> reward(String.valueOf(name)));
                } catch (ReflectiveOperationException ex) {
                    plugin.getLogger().warning("Votifier-Event konnte nicht gelesen werden: " + ex.getMessage());
                }
            }, plugin);
            plugin.getLogger().info("NuVotifier gefunden – Votes werden automatisch belohnt.");
        } catch (ClassNotFoundException ex) {
            plugin.getLogger().info("Kein NuVotifier gefunden – Vote-Belohnung nur per /votereward <Spieler>.");
        }
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("votes.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("votereward")) {
            if (args.length != 1) {
                sender.sendMessage(plugin.msg("usage-votereward"));
                return true;
            }
            reward(args[0]);
            sender.sendMessage(plugin.msg("votereward-done", "{player}", args[0]));
            return true;
        }
        List<String> lines = plugin.getConfig().getStringList("info." + name);
        if (lines.isEmpty()) {
            sender.sendMessage(plugin.msg("info-none"));
            return true;
        }
        for (String line : lines) sender.sendMessage(Text.legacy(line));
        return true;
    }

    /** Belohnung für einen Vote (sofort oder beim nächsten Join, falls offline). */
    public void reward(String username) {
        Player p = Bukkit.getPlayerExact(username);
        if (p == null) {
            String key = "pending." + username.toLowerCase(Locale.ROOT);
            data.set(key, data.getInt(key) + 1);
            save();
            return;
        }
        give(p);
    }

    private void give(Player p) {
        String kit = plugin.getConfig().getString("vote.kit", "vip");
        boolean once = plugin.getConfig().getBoolean("vote.kit-once", true);
        String claimedKey = "claimed." + p.getUniqueId();
        boolean first = !data.getBoolean(claimedKey, false);

        if (kit != null && !kit.isBlank() && (first || !once) && plugin.kits().giveItems(p, kit)) {
            data.set(claimedKey, true);
            p.sendMessage(plugin.msg("vote-kit", "{kit}", kit));
        } else {
            int gold = plugin.getConfig().getInt("vote.gold", 5);
            if (gold > 0) {
                CurrencyManager.giveValue(p, gold);
                p.sendMessage(plugin.msg("vote-gold", "{amount}", String.valueOf(gold)));
            }
        }
        save();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String key = "pending." + p.getName().toLowerCase(Locale.ROOT);
        int n = data.getInt(key, 0);
        if (n <= 0) return;
        data.set(key, null);
        save();
        for (int i = 0; i < Math.min(n, 10); i++) give(p);
    }
}
