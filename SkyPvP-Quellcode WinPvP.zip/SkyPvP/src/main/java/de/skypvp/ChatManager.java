package de.skypvp;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** /mute, /unmute, Chat-Filter (verbotene Wörter, Spam, Wiederholungen) mit Auto-Mute. */
public class ChatManager implements Listener, CommandExecutor, TabCompleter {

    public record Mute(UUID uuid, String name, String reason, String by, long created, long until) {
    }

    private final SkyPvPPlugin plugin;
    private final File file;
    private final Map<UUID, Mute> mutes = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastTime = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastText = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> violations = new ConcurrentHashMap<>();
    private volatile List<String> blocked = new ArrayList<>();
    private volatile boolean chatMuted = false;

    public ChatManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "mutes.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = c.getConfigurationSection("mutes");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection m = sec.getConfigurationSection(key);
                if (m == null) continue;
                UUID id = UUID.fromString(key);
                mutes.put(id, new Mute(id, m.getString("name", "?"), m.getString("reason", ""), m.getString("by", "?"),
                        m.getLong("created"), m.getLong("until", -1)));
            }
        }
        reload();
    }

    public void reload() {
        List<String> words = new ArrayList<>();
        for (String w : plugin.getConfig().getStringList("chat.blocked-words")) {
            String n = normalize(w).replace(" ", "");
            if (!n.isEmpty()) words.add(n);
        }
        blocked = words;
    }

    private synchronized void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Mute m : mutes.values()) {
            String p = "mutes." + m.uuid();
            c.set(p + ".name", m.name());
            c.set(p + ".reason", m.reason());
            c.set(p + ".by", m.by());
            c.set(p + ".created", m.created());
            c.set(p + ".until", m.until());
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("mutes.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    public Mute active(UUID id) {
        Mute m = mutes.get(id);
        if (m == null) return null;
        if (m.until() > 0 && m.until() <= System.currentTimeMillis()) {
            mutes.remove(id);
            save();
            return null;
        }
        return m;
    }

    public Component muteInfo(Mute m) {
        String time = m.until() < 0 ? "Permanent" : TimeUtil.format(m.until() - System.currentTimeMillis());
        return plugin.msg("mute-info", "{reason}", m.reason(), "{time}", time, "{by}", m.by());
    }

    private void applyMute(UUID id, String name, String reason, String by, long duration) {
        long now = System.currentTimeMillis();
        mutes.put(id, new Mute(id, name, reason, by, now, duration < 0 ? -1 : now + duration));
        save();
        plugin.history().add(id, name, "MUTE", reason, by, duration);
        plugin.discord().send("punish", "Mute", "**Spieler:** " + name + "\n**Grund:** " + reason + "\n**Dauer:** "
                + (duration < 0 ? "Permanent" : TimeUtil.format(duration)) + "\n**Von:** " + by, DiscordManager.GRAY);
        Player online = Bukkit.getPlayer(id);
        if (online != null) online.sendMessage(muteInfo(mutes.get(id)));
    }

    // ------------------------------------------------------------------ Chat

    @EventHandler(priority = EventPriority.LOW)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();

        if (chatMuted && !p.hasPermission("skypvp.chatmute.bypass")) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("chat-is-muted"));
            return;
        }

        Mute m = active(id);
        if (m != null) {
            e.setCancelled(true);
            p.sendMessage(muteInfo(m));
            return;
        }
        if (p.hasPermission("skypvp.chat.bypass")) return;

        String text = PlainTextComponentSerializer.plainText().serialize(e.message());
        long now = System.currentTimeMillis();

        Long last = lastTime.get(id);
        if (last != null && now - last < plugin.getConfig().getLong("chat.delay-ms", 1500)) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("chat-slow"));
            return;
        }
        if (plugin.getConfig().getBoolean("chat.block-repeat", true) && text.equalsIgnoreCase(lastText.get(id))) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("chat-repeat"));
            return;
        }
        if (containsBlocked(text)) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("chat-blocked"));
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("skypvp.report.view")) {
                    staff.sendMessage(plugin.msg("chat-filter-notify", "{player}", p.getName(), "{message}", text));
                }
            }
            int v = violations.merge(id, 1, Integer::sum);
            int max = plugin.getConfig().getInt("chat.violations-before-mute", 3);
            if (max > 0 && v >= max) {
                violations.remove(id);
                long dur = TimeUtil.parse(plugin.getConfig().getString("chat.auto-mute-duration", "10m"));
                if (dur <= 0) dur = 600_000L;
                applyMute(id, p.getName(), "Automatisch: Chat-Filter", "AutoMod", dur);
            }
            return;
        }
        lastTime.put(id, now);
        lastText.put(id, text);
    }

    private static char leet(char c) {
        return switch (c) {
            case '0' -> 'o';
            case '1', '!' -> 'i';
            case '3' -> 'e';
            case '4', '@' -> 'a';
            case '5', '$' -> 's';
            default -> c;
        };
    }

    private static String normalize(String in) {
        StringBuilder sb = new StringBuilder();
        for (char raw : in.toLowerCase(Locale.ROOT).toCharArray()) {
            char c = leet(raw);
            sb.append(Character.isLetter(c) ? c : ' ');
        }
        return sb.toString();
    }

    private boolean containsBlocked(String text) {
        String n = normalize(text);
        if (plugin.getConfig().getBoolean("chat.strict-filter", false)) {
            String joined = n.replace(" ", "");
            for (String w : blocked) if (joined.contains(w)) return true;
        } else {
            for (String token : n.trim().split("\\s+")) {
                for (String w : blocked) if (token.contains(w)) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ Befehle

    private OfflinePlayer find(String name) {
        Player p = Bukkit.getPlayerExact(name);
        return p != null ? p : Bukkit.getOfflinePlayerIfCached(name);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("chatmute")) {
            chatMuted = !chatMuted;
            Bukkit.broadcast(plugin.msg(chatMuted ? "chatmute-on" : "chatmute-off", "{player}", sender.getName()));
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("unmute")) {
            if (args.length != 1) {
                sender.sendMessage(plugin.msg("usage-unmute"));
                return true;
            }
            Mute found = null;
            for (Mute m : mutes.values()) if (m.name().equalsIgnoreCase(args[0])) found = m;
            if (found == null) {
                sender.sendMessage(plugin.msg("not-muted", "{player}", args[0]));
                return true;
            }
            mutes.remove(found.uuid());
            save();
            plugin.history().add(found.uuid(), found.name(), "UNMUTE", "-", sender.getName(), 0);
            sender.sendMessage(plugin.msg("unmute-done", "{player}", found.name()));
            Player online = Bukkit.getPlayer(found.uuid());
            if (online != null) online.sendMessage(plugin.msg("unmute-received"));
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage(plugin.msg("usage-mute"));
            return true;
        }
        long dur = TimeUtil.parse(args[1]);
        if (dur == TimeUtil.INVALID) {
            sender.sendMessage(plugin.msg("invalid-duration"));
            return true;
        }
        long max = -1;
        if (sender instanceof Player p && !p.isOp()) max = plugin.ranks().getRank(p.getUniqueId()).maxMuteMillis();
        if (max == 0 || (max > 0 && (dur < 0 || dur > max))) {
            sender.sendMessage(plugin.msg("mute-limit", "{max}", max == 0 ? "keine" : TimeUtil.format(max)));
            return true;
        }
        OfflinePlayer t = find(args[0]);
        if (t == null) {
            sender.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
            return true;
        }
        Player online = t.getPlayer();
        if (online != null && online.hasPermission("skypvp.punish.exempt") && !(sender instanceof ConsoleCommandSender)
                && !sender.hasPermission("skypvp.punish.exempt")) {
            sender.sendMessage(plugin.msg("punish-exempt"));
            return true;
        }
        String reason = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        String name = t.getName() != null ? t.getName() : args[0];
        applyMute(t.getUniqueId(), name, reason, sender.getName(), dur);
        sender.sendMessage(plugin.msg("mute-done", "{player}", name, "{duration}", TimeUtil.format(dur)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            if (cmd.getName().equalsIgnoreCase("unmute")) {
                for (Mute m : mutes.values()) if (m.name().toLowerCase(Locale.ROOT).startsWith(start)) out.add(m.name());
            } else {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
                }
            }
        } else if (args.length == 2 && cmd.getName().equalsIgnoreCase("mute")) {
            for (String s : List.of("10m", "1h", "12h", "1d", "7d")) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }
}
