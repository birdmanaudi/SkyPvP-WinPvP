package de.skypvp;

import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerListPingEvent;

/**
 * Anzeige in der Server-Liste (MOTD): Spieleranzahl, anstehendes Event und Wartungsmodus.
 * Texte und Aussehen: Abschnitt "motd" in der config.yml.
 */
public class PingManager implements Listener {

    private final SkyPvPPlugin plugin;

    public PingManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPing(ServerListPingEvent e) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("motd.enabled", true)) return;

        String l1;
        String l2;
        WhitelistManager wl = plugin.whitelist();
        EventManager ev = plugin.events();

        if (wl != null && wl.isActive()) {
            l1 = cfg.getString("motd.maintenance-line1", "&#FFB800&lWin&#E03A1E&lPvP &8» &cWartungsarbeiten");
            l2 = cfg.getString("motd.maintenance-line2", "&7Wir sind wieder da in: &f{time}");
            l2 = l2.replace("{time}", wl.remainingText());
        } else {
            l1 = cfg.getString("motd.line1", "&#FFB800&lWin&#E03A1E&lPvP&7.de &8» &fSkyPvP");
            l2 = cfg.getString("motd.line2", "&a{online}&7/&a{max} online &8| {event}");
            String event;
            if (ev != null && ev.isOpen()) {
                event = cfg.getString("motd.event-open", "&aEvent läuft jetzt!");
            } else if (ev != null && ev.isScheduled()) {
                event = cfg.getString("motd.event-scheduled", "&6Event in &f{time}")
                        .replace("{time}", TimeUtil.format(ev.startsIn()));
            } else {
                event = cfg.getString("motd.event-none", "&7Kein Event geplant");
            }
            l2 = l2.replace("{event}", event);
        }

        String online = String.valueOf(e.getNumPlayers());
        String max = String.valueOf(e.getMaxPlayers());
        l1 = l1.replace("{online}", online).replace("{max}", max);
        l2 = l2.replace("{online}", online).replace("{max}", max);

        e.motd(Component.empty().append(Text.legacy(l1)).append(Component.newline()).append(Text.legacy(l2)));
    }
}
