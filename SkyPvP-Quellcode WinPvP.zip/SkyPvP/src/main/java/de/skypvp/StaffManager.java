package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class StaffManager implements Listener, CommandExecutor {

    private final SkyPvPPlugin plugin;
    private final Set<UUID> vanished = new HashSet<>();

    public StaffManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("fly")) {
            if (plugin.combat().isInCombat(p)) {
                p.sendMessage(plugin.msg("combat-blocked"));
                return true;
            }
            boolean on = !p.getAllowFlight();
            p.setAllowFlight(on);
            if (on && !p.isOnGround()) p.setFlying(true);
            p.sendMessage(plugin.msg(on ? "fly-on" : "fly-off"));
        } else {
            boolean on = vanished.add(p.getUniqueId());
            if (!on) vanished.remove(p.getUniqueId());
            for (Player other : Bukkit.getOnlinePlayers()) {
                if (other.equals(p)) continue;
                if (on && !other.hasPermission("skypvp.vanish.see")) {
                    other.hidePlayer(plugin, p);
                } else if (!on) {
                    other.showPlayer(plugin, p);
                }
            }
            p.sendMessage(plugin.msg(on ? "vanish-on" : "vanish-off"));
        }
        return true;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player joined = e.getPlayer();
        if (joined.getGameMode() == GameMode.SURVIVAL || joined.getGameMode() == GameMode.ADVENTURE) {
            joined.setFlying(false);
            joined.setAllowFlight(false);
        }
        if (joined.hasPermission("skypvp.vanish.see")) return;
        for (UUID id : vanished) {
            Player v = Bukkit.getPlayer(id);
            if (v != null) joined.hidePlayer(plugin, v);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        vanished.remove(e.getPlayer().getUniqueId());
    }

    public boolean isVanished(Player p) {
        return vanished.contains(p.getUniqueId());
    }
}
