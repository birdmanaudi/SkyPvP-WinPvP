package de.skypvp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.List;

/** Tablist-Kopf/Fuß, Join-/Quit-Nachrichten, Willkommen für Neulinge und Auto-Broadcasts (branding.* in der config.yml). */
public class BrandingManager implements Listener {

    private final SkyPvPPlugin plugin;
    private int broadcastIndex = 0;

    public BrandingManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::updateTablist, 40L, 100L);

        long ms = TimeUtil.parse(plugin.getConfig().getString("branding.broadcast.interval", "5m"));
        long ticks = Math.max(200L, (ms > 0 ? ms : 300_000L) / 50L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::broadcast, ticks, ticks);
    }

    private String fill(String s, Player p) {
        RankManager.Rank r = plugin.ranks().getRank(p.getUniqueId());
        return s.replace("{player}", p.getName())
                .replace("{prefix}", r.prefix())
                .replace("{rank}", r.displayName())
                .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{max}", String.valueOf(Bukkit.getMaxPlayers()))
                .replace("{ping}", String.valueOf(p.getPing()))
                .replace("{server}", plugin.getConfig().getString("server-name", "WinPvP.de"));
    }

    private Component lines(List<String> list, Player p) {
        Component out = Component.empty();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) out = out.append(Component.newline());
            out = out.append(Text.legacy(fill(list.get(i), p)));
        }
        return out;
    }

    private void sendTablist(Player p) {
        if (!plugin.getConfig().getBoolean("branding.tablist.enabled", true)) return;
        p.sendPlayerListHeaderAndFooter(
                lines(plugin.getConfig().getStringList("branding.tablist.header"), p),
                lines(plugin.getConfig().getStringList("branding.tablist.footer"), p));
    }

    private void updateTablist() {
        for (Player p : Bukkit.getOnlinePlayers()) sendTablist(p);
    }

    private void broadcast() {
        if (!plugin.getConfig().getBoolean("branding.broadcast.enabled", true)) return;
        List<String> msgs = plugin.getConfig().getStringList("branding.broadcast.messages");
        if (msgs.isEmpty() || Bukkit.getOnlinePlayers().isEmpty()) return;
        String m = msgs.get(broadcastIndex++ % msgs.size());
        Bukkit.broadcast(plugin.msg("broadcast", "{message}", m));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String join = plugin.getConfig().getString("branding.join-message", "");
        e.joinMessage(join.isBlank() ? null : Text.legacy(fill(join, p)));

        if (!p.hasPlayedBefore()) {
            String first = plugin.getConfig().getString("branding.first-join-broadcast", "");
            if (!first.isBlank()) {
                Bukkit.broadcast(Text.legacy(fill(first, p).replace("{count}", String.valueOf(Bukkit.getOfflinePlayers().length + 1))));
            }
            for (String line : plugin.getConfig().getStringList("branding.welcome-lines")) {
                p.sendMessage(Text.legacy(fill(line, p)));
            }
        }
        sendTablist(p);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        String quit = plugin.getConfig().getString("branding.quit-message", "");
        if (quit.isBlank() || plugin.staff().isVanished(p)) {
            e.quitMessage(null);
        } else {
            e.quitMessage(Text.legacy(fill(quit, p)));
        }
    }
}
