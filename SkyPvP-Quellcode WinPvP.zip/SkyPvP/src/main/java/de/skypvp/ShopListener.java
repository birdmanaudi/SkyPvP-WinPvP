package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Schild-Shops.
 *
 * Erstellen (Admin, Recht skypvp.shop.create):
 *   Zeile 1: [Shop]
 *   Zeile 2: Item + optional Menge, z. B. "DIAMOND_SWORD", "ARROW 16" oder "hand" / "hand 16"
 *            ("hand" nimmt das Item aus deiner Haupthand inkl. Verzauberungen/Namen)
 *   Zeile 3: Preis in Gold-Nuggets, z. B. "27"; "3b" = 3 Barren (27), "1bl" = 1 Block (81)
 *   Zeile 4: leer
 */
public class ShopListener implements Listener {

    private static final Pattern ITEM = Pattern.compile("^(\\S+)(?:\\s+[xX]?(\\d+))?$");
    private static final Pattern PRICE = Pattern.compile("^(\\d{1,7})\\s*(bl|b|n)?$", Pattern.CASE_INSENSITIVE);

    private final SkyPvPPlugin plugin;
    private final NamespacedKey itemKey;
    private final NamespacedKey priceKey;
    private final NamespacedKey cooldownKey;
    private final Map<String, Long> lastFree = new HashMap<>();

    public ShopListener(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.itemKey = new NamespacedKey(plugin, "shop_item");
        this.priceKey = new NamespacedKey(plugin, "shop_price");
        this.cooldownKey = new NamespacedKey(plugin, "shop_cooldown");
    }

    // ------------------------------------------------------------------ Erstellen

    @EventHandler
    public void onSignChange(SignChangeEvent e) {
        String head = plain(e.line(0));
        boolean free = head.equalsIgnoreCase("[free]") || head.equalsIgnoreCase("[gratis]");
        if (!free && !head.equalsIgnoreCase("[shop]")) return;

        Player p = e.getPlayer();
        if (!p.hasPermission("skypvp.shop.create")) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("no-permission"));
            return;
        }

        ItemStack item = parseItem(p, plain(e.line(1)));
        int price = free ? 0 : parsePrice(plain(e.line(2)));
        long cooldown = 0;
        boolean badCooldown = false;
        if (free && !plain(e.line(2)).isBlank()) {
            cooldown = TimeUtil.parse(plain(e.line(2)));
            badCooldown = cooldown < 0;
        }
        final long cd = cooldown;
        if (item == null || (!free && price <= 0) || badCooldown) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("shop-invalid"));
            return;
        }

        Component name = Component.translatable(item.translationKey());
        if (item.getAmount() > 1) name = name.append(Component.text(" x" + item.getAmount()));

        e.line(0, Text.legacy(plugin.getConfig().getString("shop.sign-header", "&#FFB800&lWin&#E03A1E&lPvP")));
        e.line(1, name.color(NamedTextColor.BLACK));
        e.line(2, free ? Component.text("Gratis", NamedTextColor.DARK_GREEN)
                : Component.text(price + " Gold", NamedTextColor.GOLD));
        e.line(3, Component.text("Rechtsklick", NamedTextColor.DARK_GRAY));

        // Shop-Daten ins Schild schreiben (einen Tick später, nachdem der Text übernommen wurde)
        Block block = e.getBlock();
        byte[] bytes = item.serializeAsBytes();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!(block.getState() instanceof Sign sign)) return;
            PersistentDataContainer pdc = sign.getPersistentDataContainer();
            pdc.set(itemKey, PersistentDataType.BYTE_ARRAY, bytes);
            pdc.set(priceKey, PersistentDataType.INTEGER, price);
            pdc.set(cooldownKey, PersistentDataType.LONG, cd);
            sign.setWaxed(true); // verhindert Bearbeiten des Schilds durch Spieler
            sign.update();
        });

        String shown = pretty(item.getType()) + " x" + item.getAmount();
        p.sendMessage(free ? plugin.msg("free-created", "{item}", shown)
                : plugin.msg("shop-created", "{item}", shown, "{price}", String.valueOf(price)));
    }

    // ------------------------------------------------------------------ Kaufen

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block block = e.getClickedBlock();
        if (block == null || !Tag.ALL_SIGNS.isTagged(block.getType())) return;
        if (!(block.getState() instanceof Sign sign)) return;

        PersistentDataContainer pdc = sign.getPersistentDataContainer();
        byte[] data = pdc.get(itemKey, PersistentDataType.BYTE_ARRAY);
        Integer price = pdc.get(priceKey, PersistentDataType.INTEGER);
        if (data == null || price == null) return;

        e.setCancelled(true);
        Player p = e.getPlayer();

        Long cd = pdc.get(cooldownKey, PersistentDataType.LONG);
        if (price == 0 && cd != null && cd > 0) {
            String id = block.getWorld().getName() + block.getX() + "," + block.getY() + "," + block.getZ() + p.getUniqueId();
            long left = lastFree.getOrDefault(id, 0L) + cd - System.currentTimeMillis();
            if (left > 0) {
                p.sendMessage(plugin.msg("free-cooldown", "{time}", TimeUtil.format(left)));
                return;
            }
            lastFree.put(id, System.currentTimeMillis());
        }

        if (!CurrencyManager.pay(p, price)) {
            p.sendMessage(plugin.msg("shop-no-money", "{price}", String.valueOf(price),
                    "{balance}", String.valueOf(CurrencyManager.balance(p))));
            return;
        }

        ItemStack item = ItemStack.deserializeBytes(data);
        CurrencyManager.giveItem(p, item);
        String shown = pretty(item.getType()) + " x" + item.getAmount();
        p.sendMessage(price == 0 ? plugin.msg("free-taken", "{item}", shown)
                : plugin.msg("shop-bought", "{item}", shown, "{price}", String.valueOf(price)));
    }

    // ------------------------------------------------------------------ Schutz

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Block block = e.getBlock();
        if (!Tag.ALL_SIGNS.isTagged(block.getType())) return;
        if (!(block.getState() instanceof Sign sign)) return;
        if (!sign.getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE_ARRAY)) return;

        if (!e.getPlayer().hasPermission("skypvp.shop.create")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(plugin.msg("shop-no-break"));
        }
    }

    // ------------------------------------------------------------------ Helfer

    private ItemStack parseItem(Player p, String text) {
        Matcher m = ITEM.matcher(text.trim());
        if (!m.matches()) return null;

        int amount = 1;
        if (m.group(2) != null) {
            try {
                amount = Integer.parseInt(m.group(2));
            } catch (NumberFormatException ex) {
                return null;
            }
        }

        ItemStack item;
        if (m.group(1).equalsIgnoreCase("hand")) {
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) return null;
            item = hand.clone();
            if (m.group(2) == null) amount = hand.getAmount();
        } else {
            Material mat = Material.matchMaterial(m.group(1));
            if (mat == null || !mat.isItem() || mat.isAir()) return null;
            item = new ItemStack(mat);
        }

        item.setAmount(Math.max(1, Math.min(amount, item.getMaxStackSize())));
        return item;
    }

    private int parsePrice(String text) {
        Matcher m = PRICE.matcher(text.trim());
        if (!m.matches()) return -1;
        int n = Integer.parseInt(m.group(1));
        String unit = m.group(2) == null ? "n" : m.group(2).toLowerCase(Locale.ROOT);
        return switch (unit) {
            case "bl" -> n * CurrencyManager.value(Material.GOLD_BLOCK);
            case "b" -> n * CurrencyManager.value(Material.GOLD_INGOT);
            default -> n;
        };
    }

    private static String plain(Component c) {
        return c == null ? "" : PlainTextComponentSerializer.plainText().serialize(c);
    }

    private static String pretty(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String part : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
