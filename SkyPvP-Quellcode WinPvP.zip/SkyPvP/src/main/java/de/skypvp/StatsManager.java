package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

/** Kills, Tode, Killstreaks, Top-Liste und tägliche Belohnung. */
public class StatsManager implements CommandExecutor, TabCompleter {

    public static class Stat {
        public String name = "?";
        public int kills, deaths, streak, best;
        public String daily = "";

        public String kd() {
            return String.format(Locale.US, "%.2f", kills / (double) Math.max(1, deaths));
        }
    }

    private final SkyPvPPlugin plugin;
    private final File file;
    private final Map<UUID, Stat> stats = new HashMap<>();

    public StatsManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = c.getConfigurationSection("players");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(key);
                if (s == null) continue;
                Stat st = new Stat();
                st.name = s.getString("name", "?");
                st.kills = s.getInt("kills");
                st.deaths = s.getInt("deaths");
                st.streak = s.getInt("streak");
                st.best = s.getInt("best");
                st.daily = s.getString("daily", "");
                stats.put(UUID.fromString(key), st);
            }
        }
        Bukkit.getScheduler().runTaskTimer(plugin, this::save, 1200L, 1200L);
    }

    public Stat get(UUID id, String name) {
        Stat s = stats.computeIfAbsent(id, k -> new Stat());
        if (name != null) s.name = name;
        return s;
    }

    public void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Map.Entry<UUID, Stat> e : stats.entrySet()) {
            String p = "players." + e.getKey();
            Stat s = e.getValue();
            c.set(p + ".name", s.name);
            c.set(p + ".kills", s.kills);
            c.set(p + ".deaths", s.deaths);
            c.set(p + ".streak", s.streak);
            c.set(p + ".best", s.best);
            c.set(p + ".daily", s.daily);
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("stats.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    /** Wird bei jedem Spielertod aufgerufen. killer darf null sein. */
    public void recordDeath(Player victim, Player killer) {
        Stat v = get(victim.getUniqueId(), victim.getName());
        int lostStreak = v.streak;
        v.deaths++;
        v.streak = 0;

        int from = plugin.getConfig().getInt("killstreak.announce-from", 5);
        int every = plugin.getConfig().getInt("killstreak.announce-every", 5);

        if (killer == null || killer.equals(victim)) return;
        Stat k = get(killer.getUniqueId(), killer.getName());
        k.kills++;
        k.streak++;
        if (k.streak > k.best) k.best = k.streak;

        int bonus = plugin.getConfig().getInt("killstreak.bonus." + k.streak, 0);
        if (bonus > 0) {
            CurrencyManager.give(killer, Material.GOLD_NUGGET, bonus);
            killer.sendMessage(plugin.msg("streak-bonus", "{streak}", String.valueOf(k.streak), "{amount}", String.valueOf(bonus)));
        }
        if (every > 0 && k.streak >= from && k.streak % every == 0) {
            Bukkit.broadcast(plugin.msg("streak-announce", "{player}", killer.getName(), "{streak}", String.valueOf(k.streak)));
        }
        if (lostStreak >= from) {
            Bukkit.broadcast(plugin.msg("streak-ended", "{player}", victim.getName(), "{killer}", killer.getName(),
                    "{streak}", String.valueOf(lostStreak)));
        }
    }

    /** Tägliche Belohnung: erst ab dem zweiten Tag, danach bei jedem neuen Tag beim ersten Join. */
    public void onJoin(Player p) {
        Stat s = get(p.getUniqueId(), p.getName());
        if (!plugin.getConfig().getBoolean("daily-reward.enabled", true)) return;
        String today = LocalDate.now().toString();
        if (s.daily.isEmpty()) {
            s.daily = today; // erster Tag: keine Belohnung
            return;
        }
        if (!today.equals(s.daily)) {
            s.daily = today;
            int amount = Math.max(1, plugin.getConfig().getInt("daily-reward.amount", 5));
            CurrencyManager.give(p, Material.GOLD_NUGGET, amount);
            p.sendMessage(plugin.msg("daily-reward", "{amount}", String.valueOf(amount)));
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("top")) return top(sender, args);

        Stat st = null;
        String name;
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(plugin.msg("player-only"));
                return true;
            }
            st = get(p.getUniqueId(), p.getName());
            name = p.getName();
        } else {
            name = args[0];
            for (Stat s : stats.values()) if (s.name.equalsIgnoreCase(args[0])) st = s;
        }
        if (st == null) {
            sender.sendMessage(plugin.msg("stats-none", "{player}", name));
            return true;
        }
        for (var line : plugin.msgLines("stats-lines", "{player}", st.name, "{kills}", String.valueOf(st.kills),
                "{deaths}", String.valueOf(st.deaths), "{kd}", st.kd(), "{streak}", String.valueOf(st.streak),
                "{best}", String.valueOf(st.best))) {
            sender.sendMessage(line);
        }
        return true;
    }

    /** Sortierte Rangliste (type: kills, deaths, streak, kd). */
    public List<Stat> ranking(String type) {
        Comparator<Stat> cmp = switch (type) {
            case "deaths" -> Comparator.comparingInt((Stat s) -> -s.deaths);
            case "streak" -> Comparator.comparingInt((Stat s) -> -s.best);
            case "kd" -> Comparator.comparingDouble((Stat s) -> -(s.kills / (double) Math.max(1, s.deaths)));
            default -> Comparator.comparingInt((Stat s) -> -s.kills);
        };
        List<Stat> list = new ArrayList<>(stats.values());
        list.sort(cmp);
        return list;
    }

    public String valueOf(Stat s, String type) {
        return switch (type) {
            case "deaths" -> String.valueOf(s.deaths);
            case "streak" -> String.valueOf(s.best);
            case "kd" -> s.kd();
            default -> String.valueOf(s.kills);
        };
    }

    private boolean top(CommandSender sender, String[] args) {
        String type = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "kills";
        Comparator<Stat> cmp;
        String label;
        switch (type) {
            case "deaths" -> {
                cmp = Comparator.comparingInt(s -> -s.deaths);
                label = "Tode";
            }
            case "streak" -> {
                cmp = Comparator.comparingInt(s -> -s.best);
                label = "Beste Killstreak";
            }
            case "kd" -> {
                cmp = Comparator.comparingDouble(s -> -(s.kills / (double) Math.max(1, s.deaths)));
                label = "K/D";
            }
            default -> {
                type = "kills";
                cmp = Comparator.comparingInt(s -> -s.kills);
                label = "Kills";
            }
        }
        List<Stat> sorted = new ArrayList<>(stats.values());
        sorted.sort(cmp);
        sender.sendMessage(plugin.msg("top-title", "{type}", label));
        for (int i = 0; i < Math.min(10, sorted.size()); i++) {
            Stat s = sorted.get(i);
            String value = switch (type) {
                case "deaths" -> String.valueOf(s.deaths);
                case "streak" -> String.valueOf(s.best);
                case "kd" -> s.kd();
                default -> String.valueOf(s.kills);
            };
            sender.sendMessage(plugin.raw("top-line", "{pos}", String.valueOf(i + 1), "{player}", s.name, "{value}", value));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length != 1) return out;
        String start = args[0].toLowerCase(Locale.ROOT);
        if (cmd.getName().equalsIgnoreCase("top")) {
            for (String s : List.of("kills", "deaths", "streak", "kd")) if (s.startsWith(start)) out.add(s);
        } else {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
            }
        }
        return out;
    }
}
