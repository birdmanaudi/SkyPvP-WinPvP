package de.skypvp;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.List;

/** Sofortiger Tod unter einer einstellbaren Höhe (instant-death.y in der config.yml). */
public class InstantDeathListener implements Listener {

    private final SkyPvPPlugin plugin;

    public InstantDeathListener(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null || to.getBlockY() == e.getFrom().getBlockY()) return; // nur bei Höhenwechsel prüfen

        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("instant-death.enabled", true)) return;
        if (to.getY() >= c.getDouble("instant-death.y", 40)) return;

        Player p = e.getPlayer();
        if (p.isDead()) return;
        if (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE) return;

        List<String> worlds = c.getStringList("instant-death.worlds");
        if (!worlds.isEmpty() && !worlds.contains(to.getWorld().getName())) return;

        // Im Kampf: Gegner bekommt den Kill (Gold + Stats)
        Player opponent = plugin.combat().combatOpponent(p);
        if (opponent != null) p.setKiller(opponent);

        p.setHealth(0.0);
    }
}
