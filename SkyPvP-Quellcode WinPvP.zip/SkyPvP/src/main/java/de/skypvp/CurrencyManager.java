package de.skypvp;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;

/**
 * Gold-Währung: 1 Nugget = 1, 1 Barren = 9, 1 Block = 81.
 * Es zählen nur "normale" Goldgegenstände (ohne Namen/Verzauberung/Meta).
 */
public final class CurrencyManager {

    private CurrencyManager() {
    }

    public static int value(Material m) {
        return switch (m) {
            case GOLD_NUGGET -> 1;
            case GOLD_INGOT -> 9;
            case GOLD_BLOCK -> 81;
            default -> 0;
        };
    }

    private static boolean isCurrency(ItemStack s, Material type) {
        return s != null && s.getType() == type && !s.hasItemMeta();
    }

    /** Gesamtwert des Golds im Inventar (in Nuggets). */
    public static int balance(Player p) {
        int sum = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && !s.hasItemMeta()) sum += value(s.getType()) * s.getAmount();
        }
        return sum;
    }

    private static int count(Player p, Material type) {
        int c = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (isCurrency(s, type)) c += s.getAmount();
        }
        return c;
    }

    private static void remove(Player p, Material type, int amount) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < 36 && amount > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (!isCurrency(s, type)) continue;
            int take = Math.min(amount, s.getAmount());
            if (take == s.getAmount()) {
                inv.setItem(i, null);
            } else {
                s.setAmount(s.getAmount() - take);
            }
            amount -= take;
        }
    }

    /**
     * Bucht den Preis ab: zuerst Nuggets, dann Barren, dann Blöcke.
     * Überzahlung wird als Wechselgeld in Barren/Nuggets zurückgegeben.
     */
    public static boolean pay(Player p, int price) {
        if (price <= 0) return true;
        if (balance(p) < price) return false;

        int nuggets = count(p, Material.GOLD_NUGGET);
        int ingots = count(p, Material.GOLD_INGOT);
        int blocks = count(p, Material.GOLD_BLOCK);

        int remaining = price;
        int useN = Math.min(nuggets, remaining);
        remaining -= useN;

        int useI = 0;
        if (remaining > 0) {
            useI = Math.min(ingots, (remaining + 8) / 9);
            remaining -= useI * 9;
        }
        int useB = 0;
        if (remaining > 0) {
            useB = Math.min(blocks, (remaining + 80) / 81);
            remaining -= useB * 81;
        }

        remove(p, Material.GOLD_NUGGET, useN);
        remove(p, Material.GOLD_INGOT, useI);
        remove(p, Material.GOLD_BLOCK, useB);

        if (remaining < 0) {
            int change = -remaining;
            give(p, Material.GOLD_INGOT, change / 9);
            give(p, Material.GOLD_NUGGET, change % 9);
        }
        return true;
    }

    /** Gibt einen Wert in Nuggets als Blöcke/Barren/Nuggets aus (z. B. 90 = 1 Block + 1 Barren). */
    public static void giveValue(Player p, int value) {
        if (value <= 0) return;
        give(p, Material.GOLD_BLOCK, value / 81);
        give(p, Material.GOLD_INGOT, (value % 81) / 9);
        give(p, Material.GOLD_NUGGET, value % 9);
    }

    public static void give(Player p, Material type, int amount) {
        while (amount > 0) {
            int n = Math.min(amount, type.getMaxStackSize());
            giveItem(p, new ItemStack(type, n));
            amount -= n;
        }
    }

    /** Legt das Item ins Inventar, was nicht passt, wird vor dem Spieler gedroppt. */
    public static void giveItem(Player p, ItemStack item) {
        Collection<ItemStack> leftover = p.getInventory().addItem(item).values();
        for (ItemStack rest : leftover) {
            p.getWorld().dropItem(p.getLocation(), rest);
        }
    }
}
