package de.skypvp;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Sidebar rechts am Bildschirm. Titel, Zeilen und Platzhalter stehen in der config.yml (sidebar.*). */
public class SidebarManager {

    private static final int MAX_LINES = 15;

    private final SkyPvPPlugin plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public SidebarManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        long interval = Math.max(5, plugin.getConfig().getInt("sidebar.update-ticks", 20));
        Bukkit.getScheduler().runTaskTimer(plugin, this::update, 20L, interval);
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("sidebar.enabled", true);
    }

    private static Component legacy(String s) {
        return Text.serializer().deserialize(s);
    }

    private static String entry(int i) {
        return "§" + Integer.toHexString(i);
    }

    public void attach(Player p) {
        if (!enabled()) return;
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("sidebar", Criteria.DUMMY, legacy(plugin.getConfig().getString("sidebar.title", "&6WinPvP.de")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.numberFormat(NumberFormat.blank());
        boards.put(p.getUniqueId(), sb);
        p.setScoreboard(sb);
        plugin.ranks().syncScoreboard(p); // Rang-Präfixe auch auf dieses Scoreboard
        render(p, sb);
    }

    public void remove(Player p) {
        boards.remove(p.getUniqueId());
    }

    /** Nach /setrank reload: alles neu aufbauen. */
    public void reloadAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            boards.remove(p.getUniqueId());
            if (enabled()) {
                attach(p);
            } else {
                p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
        }
    }

    private void update() {
        if (!enabled()) return;
        for (Map.Entry<UUID, Scoreboard> e : new HashMap<>(boards).entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null) {
                boards.remove(e.getKey());
                continue;
            }
            render(p, e.getValue());
        }
    }

    private void render(Player p, Scoreboard sb) {
        Objective obj = sb.getObjective("sidebar");
        if (obj == null) return;
        obj.displayName(legacy(plugin.getConfig().getString("sidebar.title", "&6WinPvP.de")));

        StatsManager.Stat st = plugin.stats().get(p.getUniqueId(), p.getName());
        RankManager.Rank rank = plugin.ranks().getRank(p.getUniqueId());
        List<String> lines = plugin.getConfig().getStringList("sidebar.lines");
        int n = Math.min(lines.size(), MAX_LINES);

        for (int i = 0; i < n; i++) {
            String text = lines.get(i)
                    .replace("{rank}", rank.displayName())
                    .replace("{kills}", String.valueOf(st.kills))
                    .replace("{deaths}", String.valueOf(st.deaths))
                    .replace("{kd}", st.kd())
                    .replace("{streak}", String.valueOf(st.streak))
                    .replace("{best}", String.valueOf(st.best))
                    .replace("{gold}", String.valueOf(CurrencyManager.balance(p)))
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                    .replace("{server}", plugin.getConfig().getString("server-name", "WinPvP.de"));
            Score score = obj.getScore(entry(i));
            score.setScore(n - i);
            score.customName(legacy(text));
        }
        for (int i = n; i < MAX_LINES; i++) sb.resetScores(entry(i));
    }
}
