package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/** Einheitliche Text-Umwandlung: &-Farbcodes UND Hex-Farben (&#FFB800). */
public final class Text {

    private static final LegacyComponentSerializer SERIALIZER =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private Text() {
    }

    public static LegacyComponentSerializer serializer() {
        return SERIALIZER;
    }

    public static Component legacy(String s) {
        return SERIALIZER.deserialize(s);
    }
}
