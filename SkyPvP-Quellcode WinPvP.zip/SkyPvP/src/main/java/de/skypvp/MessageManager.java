package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MessageManager implements CommandExecutor {

    private final SkyPvPPlugin plugin;
    private final Map<UUID, UUID> last = new HashMap<>();

    public MessageManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        ChatManager.Mute mute = plugin.chat().active(p.getUniqueId());
        if (mute != null) {
            p.sendMessage(plugin.chat().muteInfo(mute));
            return true;
        }

        Player target;
        String text;
        if (cmd.getName().equalsIgnoreCase("reply")) {
            if (args.length < 1) {
                p.sendMessage(plugin.msg("usage-reply"));
                return true;
            }
            UUID id = last.get(p.getUniqueId());
            target = id == null ? null : Bukkit.getPlayer(id);
            if (target == null) {
                p.sendMessage(plugin.msg("reply-nobody"));
                return true;
            }
            text = String.join(" ", args);
        } else {
            if (args.length < 2) {
                p.sendMessage(plugin.msg("usage-msg"));
                return true;
            }
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null || (plugin.staff().isVanished(target) && !p.hasPermission("skypvp.vanish.see"))) {
                p.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
                return true;
            }
            if (target.equals(p)) {
                p.sendMessage(plugin.msg("msg-self"));
                return true;
            }
            text = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        }

        text = text.replaceAll("(?i)[&§][0-9a-fk-or]", ""); // keine Farbcodes von Spielern
        p.sendMessage(plugin.raw("msg-to", "{player}", target.getName(), "{message}", text));
        target.sendMessage(plugin.raw("msg-from", "{player}", p.getName(), "{message}", text));
        last.put(p.getUniqueId(), target.getUniqueId());
        last.put(target.getUniqueId(), p.getUniqueId());
        return true;
    }
}
