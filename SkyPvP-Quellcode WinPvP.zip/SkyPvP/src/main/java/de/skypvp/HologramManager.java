package de.skypvp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Schwebende Top-Listen (ohne Fremdplugin, nutzt TextDisplay).
 *  /hologram set <kills|deaths|streak|kd>   Liste an deiner Position erzeugen
 *  /hologram remove <ID> | list | refresh
 */
public class HologramManager implements CommandExecutor, TabCompleter {

    private static final List<String> TYPES = List.of("kills", "deaths", "streak", "kd");

    private static class Holo {
        String id, type;
        Location loc;
    }

    private final SkyPvPPlugin plugin;
    private final File file;
    private final Map<String, Holo> holos = new LinkedHashMap<>();
    private final Map<String, UUID> entities = new HashMap<>();

    public HologramManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "holograms.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = c.getConfigurationSection("holograms");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(id);
                if (s == null) continue;
                World w = Bukkit.getWorld(s.getString("world", ""));
                if (w == null) continue;
                Holo h = new Holo();
                h.id = id;
                h.type = s.getString("type", "kills");
                h.loc = new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"));
                holos.put(id, h);
            }
        }
        long ms = TimeUtil.parse(plugin.getConfig().getString("hologram.refresh", "1m"));
        long ticks = Math.max(100L, (ms > 0 ? ms : 60_000L) / 50L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 60L, ticks);
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Holo h : holos.values()) {
            String p = "holograms." + h.id;
            c.set(p + ".type", h.type);
            c.set(p + ".world", h.loc.getWorld().getName());
            c.set(p + ".x", h.loc.getX());
            c.set(p + ".y", h.loc.getY());
            c.set(p + ".z", h.loc.getZ());
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("holograms.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    private Component build(String type) {
        Component out = Text.legacy(plugin.getConfig().getString("hologram.titles." + type, "&6&lTop " + type));
        String line = plugin.getConfig().getString("hologram.line", "&7#{pos} &f{player} &8» &6{value}");
        int pos = 0;
        for (StatsManager.Stat s : plugin.stats().ranking(type)) {
            String v = plugin.stats().valueOf(s, type);
            if (v.equals("0") || v.equals("0.00")) continue;
            pos++;
            out = out.append(Component.newline()).append(Text.legacy(
                    line.replace("{pos}", String.valueOf(pos)).replace("{player}", s.name).replace("{value}", v)));
            if (pos >= 10) break;
        }
        if (pos == 0) {
            out = out.append(Component.newline()).append(Text.legacy(plugin.getConfig().getString("hologram.empty", "&7Noch keine Einträge")));
        }
        return out;
    }

    public void refreshAll() {
        for (Holo h : holos.values()) {
            World w = h.loc.getWorld();
            if (w == null) continue;
            Entity existing = entities.containsKey(h.id) ? Bukkit.getEntity(entities.get(h.id)) : null;
            TextDisplay td;
            if (existing instanceof TextDisplay t && t.isValid()) {
                td = t;
            } else {
                td = w.spawn(h.loc, TextDisplay.class, d -> {
                    d.setPersistent(false);
                    d.setBillboard(Display.Billboard.CENTER);
                    d.setBackgroundColor(Color.fromARGB(110, 0, 0, 0));
                    d.setShadowed(true);
                });
                entities.put(h.id, td.getUniqueId());
            }
            td.text(build(h.type));
        }
    }

    public void shutdown() {
        for (UUID id : entities.values()) {
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
        entities.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(plugin.msg("usage-hologram"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "set" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(plugin.msg("player-only"));
                    return true;
                }
                if (args.length != 2 || !TYPES.contains(args[1].toLowerCase(Locale.ROOT))) {
                    sender.sendMessage(plugin.msg("usage-hologram"));
                    return true;
                }
                int n = 1;
                while (holos.containsKey("top" + n)) n++;
                Holo h = new Holo();
                h.id = "top" + n;
                h.type = args[1].toLowerCase(Locale.ROOT);
                h.loc = p.getLocation().add(0, 2, 0);
                holos.put(h.id, h);
                save();
                refreshAll();
                p.sendMessage(plugin.msg("holo-created", "{id}", h.id, "{type}", h.type));
            }
            case "remove" -> {
                if (args.length != 2 || !holos.containsKey(args[1].toLowerCase(Locale.ROOT))) {
                    sender.sendMessage(plugin.msg("holo-unknown", "{id}", args.length > 1 ? args[1] : "?"));
                    return true;
                }
                String id = args[1].toLowerCase(Locale.ROOT);
                holos.remove(id);
                UUID eid = entities.remove(id);
                if (eid != null) {
                    Entity e = Bukkit.getEntity(eid);
                    if (e != null) e.remove();
                }
                save();
                sender.sendMessage(plugin.msg("holo-removed", "{id}", id));
            }
            case "list" -> {
                if (holos.isEmpty()) {
                    sender.sendMessage(plugin.msg("holo-none"));
                } else {
                    List<String> names = new ArrayList<>();
                    for (Holo h : holos.values()) names.add(h.id + " &8(&7" + h.type + "&8)");
                    sender.sendMessage(plugin.msg("holo-list", "{list}", String.join("&7, &f", names)));
                }
            }
            case "refresh" -> {
                refreshAll();
                sender.sendMessage(plugin.msg("holo-refreshed"));
            }
            default -> sender.sendMessage(plugin.msg("usage-hologram"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            for (String s : List.of("set", "remove", "list", "refresh")) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            for (String s : TYPES) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            for (String s : holos.keySet()) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }
}
