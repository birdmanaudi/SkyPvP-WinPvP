package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Event-System:
 *   /event                              Spieler: zur Arena (sobald das Event gestartet ist)
 *   /event ein [Startzeit] [Dauer]      Event ankündigen: startet erst nach der Startzeit (Countdown im Chat).
 *                                       Ohne Startzeit startet es sofort. Ohne Dauer läuft es bis /event aus.
 *   /event aus                          Event beenden bzw. angekündigtes Event absagen
 *   /event setspawn [Radius]            Arena-Spawn + Schutzzone (kein PvP/Schaden/Bauen) an deiner Position
 *   /event status                       zeigt den aktuellen Stand
 */
public class EventManager implements Listener, CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;
    private final File file;
    private Location arena;
    private double radius;

    private boolean open;          // Event läuft (Spieler dürfen /event nutzen)
    private long startsAt;         // > 0: Event ist angekündigt und startet zu diesem Zeitpunkt
    private long pendingDuration;  // Dauer, die nach dem Start gilt (0 = unbegrenzt)
    private long endsAt;           // > 0: Event endet automatisch zu diesem Zeitpunkt

    private final Set<UUID> participants = new HashSet<>();
    private final Set<Long> announced = new HashSet<>();

    public EventManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "event.yml");
        this.radius = plugin.getConfig().getDouble("event.safe-radius", 8);
        load();
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        World w = Bukkit.getWorld(c.getString("world", ""));
        if (w == null) return;
        arena = new Location(w, c.getDouble("x"), c.getDouble("y"), c.getDouble("z"),
                (float) c.getDouble("yaw"), (float) c.getDouble("pitch"));
        radius = c.getDouble("radius", radius);
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        c.set("world", arena.getWorld().getName());
        c.set("x", arena.getX());
        c.set("y", arena.getY());
        c.set("z", arena.getZ());
        c.set("yaw", arena.getYaw());
        c.set("pitch", arena.getPitch());
        c.set("radius", radius);
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("event.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    /** Schutzzone um den Arena-Spawn (wird von SpawnManager wie der Spawn-Schutz behandelt). */
    public boolean isInSafeZone(Location l) {
        if (arena == null || l.getWorld() == null || !l.getWorld().equals(arena.getWorld())) return false;
        double dx = l.getX() - arena.getX();
        double dz = l.getZ() - arena.getZ();
        return dx * dx + dz * dz <= radius * radius;
    }

    private boolean scheduled() {
        return !open && startsAt > 0;
    }

    public boolean isOpen() {
        return open;
    }

    public boolean isScheduled() {
        return scheduled();
    }

    /** Millisekunden bis zum Start eines angekündigten Events (0 = nichts angekündigt). */
    public long startsIn() {
        return startsAt > 0 ? Math.max(0, startsAt - System.currentTimeMillis()) : 0;
    }

    /** Rund um die Event-Arena sind Enderperlen verboten (event.pearl-radius). */
    public boolean isInPearlZone(Location l) {
        if (arena == null || l == null || l.getWorld() == null || !l.getWorld().equals(arena.getWorld())) return false;
        double r = plugin.getConfig().getDouble("event.pearl-radius", 60);
        double dx = l.getX() - arena.getX();
        double dz = l.getZ() - arena.getZ();
        return dx * dx + dz * dz <= r * r;
    }

    private List<Long> thresholds() {
        List<Long> out = new ArrayList<>();
        for (String raw : plugin.getConfig().getStringList("event.countdown")) {
            long ms = TimeUtil.parse(raw);
            if (ms > 0) out.add(ms / 1000);
        }
        return out;
    }

    private String unlimitedText() {
        return plugin.getConfig().getString("messages.unlimited", "bis auf Weiteres");
    }

    private void markDone(long totalMs) {
        announced.clear();
        for (long s : thresholds()) if (s * 1000 >= totalMs) announced.add(s);
    }

    // ------------------------------------------------------------------ Ablauf

    /** Event ankündigen: startet nach delayMs (Vorfreude-Countdown im Chat). */
    private void schedule(long delayMs, long durationMs) {
        startsAt = System.currentTimeMillis() + delayMs;
        pendingDuration = durationMs;
        markDone(delayMs);
        plugin.discord().send("event", "Event angekündigt", "Start in **" + TimeUtil.format(delayMs) + "**", DiscordManager.GOLD);
        for (Component line : plugin.msgLines("event-announce", "{time}", TimeUtil.format(delayMs))) {
            Bukkit.broadcast(line);
        }
    }

    /** Event startet jetzt: Spieler dürfen /event nutzen. */
    private void startNow(long durationMs) {
        open = true;
        startsAt = 0;
        pendingDuration = 0;
        endsAt = durationMs > 0 ? System.currentTimeMillis() + durationMs : 0;
        if (durationMs > 0) markDone(durationMs); else announced.clear();
        plugin.discord().send("event", "Event gestartet", "Das Event läuft jetzt – /event auf dem Server!", DiscordManager.GREEN);
        String time = durationMs > 0 ? TimeUtil.format(durationMs) : unlimitedText();
        for (Component line : plugin.msgLines("event-open", "{time}", time)) {
            Bukkit.broadcast(line.clickEvent(ClickEvent.runCommand("/event")));
        }
    }

    private void close() {
        open = false;
        startsAt = 0;
        endsAt = 0;
        pendingDuration = 0;
        announced.clear();
        plugin.discord().send("event", "Event beendet", "Danke fürs Mitmachen!", DiscordManager.GRAY);
        Bukkit.broadcast(plugin.msg("event-ended"));
        if (plugin.getConfig().getBoolean("event.send-back-on-end", true)) {
            Location spawn = plugin.spawn().getSpawn();
            for (UUID id : new ArrayList<>(participants)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.teleport(spawn);
            }
        }
        participants.clear();
    }

    private void cancelScheduled() {
        startsAt = 0;
        pendingDuration = 0;
        announced.clear();
        Bukkit.broadcast(plugin.msg("event-cancelled"));
    }

    private void tick() {
        long now = System.currentTimeMillis();

        if (scheduled()) {
            long rem = startsAt - now;
            if (rem <= 0) {
                startNow(pendingDuration);
                return;
            }
            long remSec = (rem + 999) / 1000;
            for (long s : thresholds()) {
                if (remSec <= s && announced.add(s)) {
                    Bukkit.broadcast(plugin.msg("event-countdown", "{time}", TimeUtil.format(s * 1000)));
                }
            }
            return;
        }

        if (open && endsAt > 0) {
            long rem = endsAt - now;
            if (rem <= 0) {
                close();
                return;
            }
            long remSec = (rem + 999) / 1000;
            for (long s : thresholds()) {
                if (remSec <= s && announced.add(s)) {
                    Bukkit.broadcast(plugin.msg("event-end-countdown", "{time}", TimeUtil.format(s * 1000)));
                }
            }
        }
    }

    private void join(Player p) {
        if (!open) {
            if (scheduled()) {
                p.sendMessage(plugin.msg("event-not-started", "{time}", TimeUtil.format(startsAt - System.currentTimeMillis())));
            } else {
                p.sendMessage(plugin.msg("event-closed"));
            }
            return;
        }
        if (arena == null) {
            p.sendMessage(plugin.msg("event-no-arena"));
            return;
        }
        if (plugin.combat().isInCombat(p)) {
            p.sendMessage(plugin.msg("combat-blocked"));
            return;
        }
        p.teleport(arena.clone());
        participants.add(p.getUniqueId());
        p.sendMessage(plugin.msg("event-joined"));
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);

        if (sub.isEmpty() || sub.equals("join")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(plugin.msg("player-only"));
                return true;
            }
            join(p);
            return true;
        }
        if (sub.equals("status") || sub.equals("info")) {
            long now = System.currentTimeMillis();
            if (open) {
                String time = endsAt > 0 ? TimeUtil.format(endsAt - now) : unlimitedText();
                sender.sendMessage(plugin.msg("event-status-open", "{time}", time));
            } else if (scheduled()) {
                sender.sendMessage(plugin.msg("event-status-scheduled", "{time}", TimeUtil.format(startsAt - now)));
            } else {
                sender.sendMessage(plugin.msg("event-status-closed"));
            }
            return true;
        }

        if (!sender.hasPermission("skypvp.event.manage")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }

        switch (sub) {
            case "ein", "on", "start" -> {
                if (arena == null) {
                    sender.sendMessage(plugin.msg("event-no-arena"));
                    return true;
                }
                if (open || scheduled()) {
                    sender.sendMessage(plugin.msg("event-already-open"));
                    return true;
                }
                long delay = 0;
                long duration = 0;
                if (args.length >= 2) {
                    delay = TimeUtil.parse(args[1]);
                    if (delay == TimeUtil.INVALID) {
                        sender.sendMessage(plugin.msg("invalid-duration"));
                        return true;
                    }
                    if (delay == TimeUtil.PERM) delay = 0;
                }
                if (args.length >= 3) {
                    duration = TimeUtil.parse(args[2]);
                    if (duration == TimeUtil.INVALID) {
                        sender.sendMessage(plugin.msg("invalid-duration"));
                        return true;
                    }
                    if (duration == TimeUtil.PERM) duration = 0;
                }
                if (delay > 0) schedule(delay, duration); else startNow(duration);
            }
            case "aus", "off", "stop", "ende" -> {
                if (open) {
                    close();
                } else if (scheduled()) {
                    cancelScheduled();
                } else {
                    sender.sendMessage(plugin.msg("event-not-open"));
                }
            }
            case "setspawn" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(plugin.msg("player-only"));
                    return true;
                }
                double r = plugin.getConfig().getDouble("event.safe-radius", 8);
                if (args.length >= 2) {
                    try {
                        r = Double.parseDouble(args[1]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(plugin.msg("usage-event"));
                        return true;
                    }
                }
                radius = Math.max(1, Math.min(200, r));
                arena = p.getLocation();
                save();
                p.sendMessage(plugin.msg("event-arena-set", "{radius}", String.valueOf((int) radius)));
            }
            default -> sender.sendMessage(plugin.msg("usage-event"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        boolean manage = sender.hasPermission("skypvp.event.manage");
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("status"));
            if (manage) subs.addAll(List.of("ein", "aus", "setspawn"));
            for (String s : subs) if (s.startsWith(start)) out.add(s);
        } else if (manage && args[0].equalsIgnoreCase("ein")) {
            List<String> opts = args.length == 2 ? List.of("5m", "10m", "15m", "30m") : List.of("15m", "30m", "1h");
            if (args.length <= 3) for (String s : opts) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        participants.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        participants.remove(e.getEntity().getUniqueId());
    }
}
