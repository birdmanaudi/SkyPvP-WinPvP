package de.skypvp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Wartungsmodus / Whitelist mit optionaler Zeit:
 *   /wl on [Zeit]  /wl off  /wl add <Spieler>  /wl remove <Spieler>  /wl list  /wl status
 * Ist die Zeit abgelaufen, schaltet sich der Modus automatisch aus. OPs dürfen immer joinen.
 */
public class WhitelistManager implements Listener, CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;
    private final File file;
    private volatile boolean enabled;
    private volatile long until;
    private final Map<UUID, String> players = new ConcurrentHashMap<>();

    public WhitelistManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "whitelist.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        enabled = c.getBoolean("enabled", false);
        until = c.getLong("until", 0);
        ConfigurationSection sec = c.getConfigurationSection("players");
        if (sec != null) {
            for (String key : sec.getKeys(false)) players.put(UUID.fromString(key), sec.getString(key, "?"));
        }
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 200L, 200L);
    }

    private synchronized void save() {
        YamlConfiguration c = new YamlConfiguration();
        c.set("enabled", enabled);
        c.set("until", until);
        for (Map.Entry<UUID, String> e : players.entrySet()) c.set("players." + e.getKey(), e.getValue());
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("whitelist.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    /** Aktiv = eingeschaltet und Zeit noch nicht abgelaufen. */
    public boolean isActive() {
        return enabled && !(until > 0 && until <= System.currentTimeMillis());
    }

    public String remainingText() {
        return until > 0 ? TimeUtil.format(until - System.currentTimeMillis())
                : plugin.getConfig().getString("messages.unlimited", "bis auf Weiteres");
    }

    /** Läuft alle 10 Sekunden: abgelaufene Wartung automatisch beenden. */
    private void tick() {
        if (enabled && until > 0 && until <= System.currentTimeMillis()) {
            enabled = false;
            until = 0;
            save();
            Bukkit.broadcast(plugin.msg("wl-ended"));
            plugin.discord().send("maintenance", "Wartungsmodus beendet", "Der Server ist wieder für alle offen.", DiscordManager.GREEN);
        }
    }

    private Component screen() {
        Component out = Component.empty();
        List<String> lines = plugin.getConfig().getStringList("whitelist.kick-lines");
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) out = out.append(Component.newline());
            out = out.append(Text.legacy(lines.get(i).replace("{time}", remainingText())));
        }
        return out;
    }

    private boolean mayJoin(UUID id) {
        return players.containsKey(id) || Bukkit.getOfflinePlayer(id).isOp();
    }

    // ------------------------------------------------------------------ Ereignisse

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (!isActive() || mayJoin(e.getUniqueId())) return;
        e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_WHITELIST, screen());
    }

    // ------------------------------------------------------------------ Befehle

    private OfflinePlayer find(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
        return cached != null ? cached : Bukkit.getOfflinePlayer(name);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(plugin.msg("usage-wl"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "on", "ein" -> {
                long dur = 0;
                if (args.length >= 2) {
                    dur = TimeUtil.parse(args[1]);
                    if (dur == TimeUtil.INVALID) {
                        sender.sendMessage(plugin.msg("invalid-duration"));
                        return true;
                    }
                    if (dur == TimeUtil.PERM) dur = 0;
                }
                enabled = true;
                until = dur > 0 ? System.currentTimeMillis() + dur : 0;
                save();
                sender.sendMessage(plugin.msg("wl-on", "{time}", remainingText()));
                plugin.discord().send("maintenance", "Wartungsmodus AN", "Dauer: **" + remainingText() + "**", DiscordManager.GOLD);
                if (plugin.getConfig().getBoolean("whitelist.kick-online", true)) {
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (!mayJoin(p.getUniqueId())) p.kick(screen());
                    }
                }
            }
            case "off", "aus" -> {
                enabled = false;
                until = 0;
                save();
                sender.sendMessage(plugin.msg("wl-off"));
                plugin.discord().send("maintenance", "Wartungsmodus AUS", "Der Server ist wieder für alle offen.", DiscordManager.GREEN);
            }
            case "add" -> {
                if (args.length != 2) {
                    sender.sendMessage(plugin.msg("usage-wl"));
                    return true;
                }
                OfflinePlayer t = find(args[1]);
                String name = t.getName() != null ? t.getName() : args[1];
                players.put(t.getUniqueId(), name);
                save();
                sender.sendMessage(plugin.msg("wl-added", "{player}", name));
            }
            case "remove", "del" -> {
                if (args.length != 2) {
                    sender.sendMessage(plugin.msg("usage-wl"));
                    return true;
                }
                UUID found = null;
                for (Map.Entry<UUID, String> e : players.entrySet()) {
                    if (e.getValue().equalsIgnoreCase(args[1])) found = e.getKey();
                }
                if (found == null) {
                    sender.sendMessage(plugin.msg("wl-not-listed", "{player}", args[1]));
                    return true;
                }
                players.remove(found);
                save();
                sender.sendMessage(plugin.msg("wl-removed", "{player}", args[1]));
            }
            case "list" -> {
                if (players.isEmpty()) {
                    sender.sendMessage(plugin.msg("wl-empty"));
                } else {
                    List<String> names = new ArrayList<>(players.values());
                    Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
                    sender.sendMessage(plugin.msg("wl-list", "{count}", String.valueOf(names.size()),
                            "{players}", String.join("&7, &f", names)));
                }
            }
            case "status" -> sender.sendMessage(isActive()
                    ? plugin.msg("wl-status-on", "{time}", remainingText())
                    : plugin.msg("wl-status-off"));
            default -> sender.sendMessage(plugin.msg("usage-wl"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            for (String s : List.of("on", "off", "add", "remove", "list", "status")) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "on", "ein" -> {
                    for (String s : List.of("30m", "1h", "2h", "1d")) if (s.startsWith(start)) out.add(s);
                }
                case "add" -> {
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
                    }
                }
                case "remove", "del" -> {
                    for (String n : players.values()) if (n.toLowerCase(Locale.ROOT).startsWith(start)) out.add(n);
                }
                default -> {
                }
            }
        }
        return out;
    }
}
