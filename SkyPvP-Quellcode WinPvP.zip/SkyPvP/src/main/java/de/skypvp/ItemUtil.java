package de.skypvp;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;

public final class ItemUtil {

    private ItemUtil() {
    }

    /** Zeilenformat: "MATERIAL MENGE ENCHANT:STUFE ..." (z. B. "GOLD_INGOT 10"). */
    public static ItemStack parse(String line) {
        String[] t = line.trim().split("\\s+");
        if (t.length == 0) return null;
        Material m = Material.matchMaterial(t[0]);
        if (m == null || !m.isItem() || m.isAir()) return null;
        int amount = 1;
        if (t.length > 1) {
            try {
                amount = Integer.parseInt(t[1]);
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        ItemStack item = new ItemStack(m, Math.max(1, amount));
        for (int i = 2; i < t.length; i++) {
            String[] e = t[i].split(":");
            if (e.length != 2) continue;
            Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(e[0].toLowerCase(Locale.ROOT)));
            if (ench == null) continue;
            try {
                item.addUnsafeEnchantment(ench, Integer.parseInt(e[1]));
            } catch (NumberFormatException ignored) {
            }
        }
        return item;
    }

    public static String pretty(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String part : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
