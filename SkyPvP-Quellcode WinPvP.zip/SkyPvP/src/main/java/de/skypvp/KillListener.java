package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.net.InetSocketAddress;

public class KillListener implements Listener {

    private final SkyPvPPlugin plugin;

    public KillListener(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    private static boolean sameIp(Player a, Player b) {
        InetSocketAddress x = a.getAddress();
        InetSocketAddress y = b.getAddress();
        return x != null && y != null && x.getAddress() != null && x.getAddress().equals(y.getAddress());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer != null && killer.equals(victim)) killer = null;

        // Anti-Farming: gleiche IP -> Kill zählt nicht (Team wird informiert und prüft selbst)
        if (killer != null && plugin.getConfig().getBoolean("antifarm.same-ip", true) && sameIp(killer, victim)) {
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("skypvp.report.view")) {
                    staff.sendMessage(plugin.msg("antifarm-notify", "{killer}", killer.getName(), "{victim}", victim.getName()));
                }
            }
            plugin.discord().send("antifarm", "Anti-Farming: gleiche IP",
                    "**" + killer.getName() + "** hat **" + victim.getName() + "** getötet – gleiche IP, Kill wurde nicht gewertet.",
                    DiscordManager.GRAY);
            killer = null;
        }

        if (killer != null) {
            int reward = Math.max(1, plugin.getConfig().getInt("kill-reward", 1));
            CurrencyManager.give(killer, Material.GOLD_NUGGET, reward);
            killer.sendMessage(plugin.msg("kill-reward", "{amount}", String.valueOf(reward)));

            plugin.trophies().award(killer, victim);

            if (plugin.getConfig().getBoolean("killeffect.lightning", true)
                    && killer.hasPermission("skypvp.killeffect.lightning")) {
                victim.getWorld().strikeLightningEffect(victim.getLocation());
            }
        }
        plugin.stats().recordDeath(victim, killer);
    }
}
