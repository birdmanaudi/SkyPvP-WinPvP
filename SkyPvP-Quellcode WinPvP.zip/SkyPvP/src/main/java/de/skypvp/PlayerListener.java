package de.skypvp;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {

    private final SkyPvPPlugin plugin;

    public PlayerListener(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.ranks().apply(e.getPlayer());
        plugin.sidebar().attach(e.getPlayer());
        plugin.stats().onJoin(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.sidebar().remove(e.getPlayer());
        plugin.ranks().remove(e.getPlayer());
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        RankManager.Rank rank = plugin.ranks().getRank(e.getPlayer().getUniqueId());
        e.renderer(ChatRenderer.viewerUnaware((source, displayName, message) ->
                rank.prefixComponent()
                        .append(Component.text(source.getName(), rank.color()))
                        .append(Component.text(" » ", NamedTextColor.DARK_GRAY))
                        .append(message.color(NamedTextColor.WHITE))));
    }
}
