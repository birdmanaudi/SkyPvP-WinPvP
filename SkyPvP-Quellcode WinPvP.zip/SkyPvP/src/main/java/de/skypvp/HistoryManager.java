package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Verlauf aller Strafen (Kick, Ban, Mute ...) pro Spieler: /history <Spieler> */
public class HistoryManager implements CommandExecutor, TabCompleter {

    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("dd.MM.yy HH:mm").withZone(ZoneId.systemDefault());

    private final SkyPvPPlugin plugin;
    private final File file;
    private final YamlConfiguration cfg;

    public HistoryManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "history.yml");
        this.cfg = YamlConfiguration.loadConfiguration(file);
    }

    /** type: KICK, BAN, TEMPBAN, UNBAN, MUTE, UNMUTE. durationMs: -1 = permanent, 0 = keine Dauer. */
    public synchronized void add(UUID id, String name, String type, String reason, String by, long durationMs) {
        List<String> list = new ArrayList<>(cfg.getStringList("history." + id));
        list.add(type + "|" + System.currentTimeMillis() + "|" + by + "|" + durationMs + "|" + reason.replace("\n", " "));
        cfg.set("history." + id, list);
        cfg.set("names." + id, name);
        try {
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("history.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    private UUID find(String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p != null) return p.getUniqueId();
        OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(name);
        if (off != null) return off.getUniqueId();
        ConfigurationSection names = cfg.getConfigurationSection("names");
        if (names != null) {
            for (String key : names.getKeys(false)) {
                if (name.equalsIgnoreCase(names.getString(key))) return UUID.fromString(key);
            }
        }
        return null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length != 1) {
            sender.sendMessage(plugin.msg("usage-history"));
            return true;
        }
        UUID id = find(args[0]);
        if (id == null) {
            sender.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
            return true;
        }
        List<String> list = cfg.getStringList("history." + id);
        if (list.isEmpty()) {
            sender.sendMessage(plugin.msg("history-empty", "{player}", args[0]));
            return true;
        }
        int show = Math.max(1, plugin.getConfig().getInt("history.show-last", 10));
        sender.sendMessage(plugin.msg("history-header", "{player}", args[0], "{count}", String.valueOf(list.size())));
        for (int i = Math.max(0, list.size() - show); i < list.size(); i++) {
            String[] t = list.get(i).split("\\|", 5);
            if (t.length < 5) continue;
            long dur = Long.parseLong(t[3]);
            String durText = dur < 0 ? "Permanent" : dur == 0 ? "-" : TimeUtil.format(dur);
            sender.sendMessage(plugin.raw("history-line", "{date}", DATE.format(Instant.ofEpochMilli(Long.parseLong(t[1]))),
                    "{type}", t[0], "{by}", t[2], "{duration}", durText, "{reason}", t[4]));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }
}
