package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** /kick, /ban, /tempban, /unban inkl. Bann-Bildschirm (Server, Grund, Dauer, Banner). */
public class PunishManager implements Listener, CommandExecutor, TabCompleter {

    public record Ban(UUID uuid, String name, String reason, String by, long created, long until) {
    }

    private final SkyPvPPlugin plugin;
    private final File file;
    private final Map<UUID, Ban> bans = new ConcurrentHashMap<>();

    public PunishManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "bans.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = c.getConfigurationSection("bans");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection b = sec.getConfigurationSection(key);
                if (b == null) continue;
                UUID id = UUID.fromString(key);
                bans.put(id, new Ban(id, b.getString("name", "?"), b.getString("reason", ""), b.getString("by", "?"),
                        b.getLong("created"), b.getLong("until", -1)));
            }
        }
    }

    private synchronized void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Ban b : bans.values()) {
            String p = "bans." + b.uuid();
            c.set(p + ".name", b.name());
            c.set(p + ".reason", b.reason());
            c.set(p + ".by", b.by());
            c.set(p + ".created", b.created());
            c.set(p + ".until", b.until());
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("bans.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ Bildschirme

    private Component screen(String headline, String reason, String by, String duration) {
        String server = plugin.getConfig().getString("server-name", "WinPvP.de");
        Component c = Text.legacy(plugin.getConfig().getString("server-title", "&6&l" + server))
                .append(Component.newline())
                .append(Component.text(headline, NamedTextColor.RED))
                .append(Component.newline()).append(Component.newline())
                .append(Component.text("Grund: ", NamedTextColor.GRAY))
                .append(Component.text(reason, NamedTextColor.WHITE))
                .append(Component.newline());
        if (duration != null) {
            c = c.append(Component.text("Dauer: ", NamedTextColor.GRAY))
                    .append(Component.text(duration, NamedTextColor.WHITE))
                    .append(Component.newline());
        }
        return c.append(Component.text("Gebannt von: ", NamedTextColor.GRAY))
                .append(Component.text(by, NamedTextColor.WHITE));
    }

    private Component banScreen(Ban b) {
        String dur;
        if (b.until() < 0) {
            dur = "Permanent";
        } else {
            dur = TimeUtil.format(b.until() - b.created()) + " (noch " + TimeUtil.format(b.until() - System.currentTimeMillis()) + ")";
        }
        return screen("Du wurdest vom Server gebannt!", b.reason(), b.by(), dur);
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        Ban b = bans.get(e.getUniqueId());
        if (b == null) return;
        if (b.until() > 0 && b.until() <= System.currentTimeMillis()) {
            bans.remove(e.getUniqueId());
            save();
            return;
        }
        e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, banScreen(b));
    }

    // ------------------------------------------------------------------ Befehle

    private OfflinePlayer find(String name) {
        Player p = Bukkit.getPlayerExact(name);
        return p != null ? p : Bukkit.getOfflinePlayerIfCached(name);
    }

    private boolean isExempt(CommandSender sender, OfflinePlayer target) {
        Player online = target.getPlayer();
        return online != null && online.hasPermission("skypvp.punish.exempt")
                && !(sender instanceof ConsoleCommandSender) && !sender.hasPermission("skypvp.punish.exempt");
    }

    private static String join(String[] args, int from, String fallback) {
        if (args.length <= from) return fallback;
        return String.join(" ", java.util.Arrays.copyOfRange(args, from, args.length));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String by = sender.getName();
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "kick" -> {
                if (args.length < 1) {
                    sender.sendMessage(plugin.msg("usage-kick"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[0]);
                if (t == null) {
                    sender.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
                    return true;
                }
                if (isExempt(sender, t)) {
                    sender.sendMessage(plugin.msg("punish-exempt"));
                    return true;
                }
                String reason = join(args, 1, "Kein Grund angegeben");
                t.kick(screenKick(reason, by));
                plugin.history().add(t.getUniqueId(), t.getName(), "KICK", reason, by, 0);
                plugin.discord().send("punish", "Kick", "**Spieler:** " + t.getName() + "\n**Grund:** " + reason
                        + "\n**Von:** " + by, DiscordManager.GRAY);
                sender.sendMessage(plugin.msg("kick-done", "{player}", t.getName()));
            }
            case "ban" -> {
                if (args.length < 1) {
                    sender.sendMessage(plugin.msg("usage-ban"));
                    return true;
                }
                OfflinePlayer t = find(args[0]);
                if (t == null) {
                    sender.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
                    return true;
                }
                if (isExempt(sender, t)) {
                    sender.sendMessage(plugin.msg("punish-exempt"));
                    return true;
                }
                applyBan(t, join(args, 1, "Kein Grund angegeben"), by, -1);
                sender.sendMessage(plugin.msg("ban-done", "{player}", name(t, args[0]), "{duration}", "Permanent"));
            }
            case "tempban" -> {
                if (args.length < 3) {
                    sender.sendMessage(plugin.msg("usage-tempban"));
                    return true;
                }
                long dur = TimeUtil.parse(args[1]);
                if (dur == TimeUtil.INVALID) {
                    sender.sendMessage(plugin.msg("invalid-duration"));
                    return true;
                }
                // Limit des Rangs (OPs und Konsole: unbegrenzt)
                long max = -1;
                if (sender instanceof Player p && !p.isOp()) max = plugin.ranks().getRank(p.getUniqueId()).maxTempbanMillis();
                if (max == 0 || (max > 0 && (dur < 0 || dur > max))) {
                    sender.sendMessage(plugin.msg("tempban-limit", "{max}", max == 0 ? "keine" : TimeUtil.format(max)));
                    return true;
                }
                OfflinePlayer t = find(args[0]);
                if (t == null) {
                    sender.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
                    return true;
                }
                if (isExempt(sender, t)) {
                    sender.sendMessage(plugin.msg("punish-exempt"));
                    return true;
                }
                applyBan(t, join(args, 2, "Kein Grund angegeben"), by, dur);
                sender.sendMessage(plugin.msg("ban-done", "{player}", name(t, args[0]), "{duration}", TimeUtil.format(dur)));
            }
            case "unban" -> {
                if (args.length != 1) {
                    sender.sendMessage(plugin.msg("usage-unban"));
                    return true;
                }
                Ban found = null;
                for (Ban b : bans.values()) if (b.name().equalsIgnoreCase(args[0])) found = b;
                if (found == null) {
                    sender.sendMessage(plugin.msg("not-banned", "{player}", args[0]));
                    return true;
                }
                bans.remove(found.uuid());
                save();
                plugin.history().add(found.uuid(), found.name(), "UNBAN", "-", by, 0);
                plugin.discord().send("punish", "Unban", "**Spieler:** " + found.name() + "\n**Von:** " + by, DiscordManager.GREEN);
                sender.sendMessage(plugin.msg("unban-done", "{player}", found.name()));
            }
            default -> {
            }
        }
        return true;
    }

    private Component screenKick(String reason, String by) {
        String server = plugin.getConfig().getString("server-name", "WinPvP.de");
        return Text.legacy(plugin.getConfig().getString("server-title", "&6&l" + server))
                .append(Component.newline())
                .append(Component.text("Du wurdest gekickt!", NamedTextColor.RED))
                .append(Component.newline()).append(Component.newline())
                .append(Component.text("Grund: ", NamedTextColor.GRAY)).append(Component.text(reason, NamedTextColor.WHITE))
                .append(Component.newline())
                .append(Component.text("Gekickt von: ", NamedTextColor.GRAY)).append(Component.text(by, NamedTextColor.WHITE));
    }

    private static String name(OfflinePlayer t, String fallback) {
        return t.getName() != null ? t.getName() : fallback;
    }

    private void applyBan(OfflinePlayer t, String reason, String by, long duration) {
        long now = System.currentTimeMillis();
        Ban b = new Ban(t.getUniqueId(), name(t, "?"), reason, by, now, duration < 0 ? -1 : now + duration);
        bans.put(b.uuid(), b);
        save();
        plugin.history().add(b.uuid(), b.name(), duration < 0 ? "BAN" : "TEMPBAN", reason, by, duration);
        plugin.discord().send("punish", duration < 0 ? "Permanenter Bann" : "Tempban", "**Spieler:** " + b.name()
                + "\n**Grund:** " + reason + "\n**Dauer:** " + (duration < 0 ? "Permanent" : TimeUtil.format(duration))
                + "\n**Von:** " + by, DiscordManager.RED);
        Player online = t.getPlayer();
        if (online != null) online.kick(banScreen(b));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            if (name.equals("unban")) {
                for (Ban b : bans.values()) if (b.name().toLowerCase(Locale.ROOT).startsWith(start)) out.add(b.name());
            } else {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
                }
            }
        } else if (args.length == 2 && name.equals("tempban")) {
            for (String s : List.of("1h", "12h", "1d", "2d", "7d", "30d")) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }
}
