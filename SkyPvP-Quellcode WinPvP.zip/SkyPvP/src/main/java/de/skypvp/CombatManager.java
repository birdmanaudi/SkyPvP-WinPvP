package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Combat-Log: jede Berührung (Schwert, Hand, Bogen, Schneeball ...) startet den Kampf-Timer. */
public class CombatManager implements Listener {

    private final SkyPvPPlugin plugin;
    private final Map<UUID, Long> until = new HashMap<>();
    private final Map<UUID, UUID> opponent = new HashMap<>();

    public CombatManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public static Player attacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Player p) return p;
        return null;
    }

    private long millis() {
        return Math.max(1, plugin.getConfig().getInt("combat.seconds", 10)) * 1000L;
    }

    public boolean isInCombat(Player p) {
        Long u = until.get(p.getUniqueId());
        return u != null && u > System.currentTimeMillis();
    }

    /** Gegner, mit dem der Spieler gerade im Kampf ist (sonst null). */
    public Player combatOpponent(Player p) {
        if (!isInCombat(p)) return null;
        UUID id = opponent.get(p.getUniqueId());
        return id == null ? null : Bukkit.getPlayer(id);
    }

    public void tag(Player a, Player b) {
        if (a.equals(b)) return;
        if (plugin.spawn().isInSpawn(a.getLocation()) || plugin.spawn().isInSpawn(b.getLocation())) return;
        mark(a, b);
        mark(b, a);
    }

    private void mark(Player p, Player opp) {
        boolean was = isInCombat(p);
        until.put(p.getUniqueId(), System.currentTimeMillis() + millis());
        opponent.put(p.getUniqueId(), opp.getUniqueId());
        if (!was) {
            p.sendMessage(plugin.msg("combat-start"));
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
        }
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (UUID id : new ArrayList<>(until.keySet())) {
            Player p = Bukkit.getPlayer(id);
            long end = until.get(id);
            if (p == null) {
                until.remove(id);
            } else if (end <= now) {
                until.remove(id);
                opponent.remove(id);
                p.sendActionBar(Component.empty());
                p.setCooldown(Material.ENDER_PEARL, 0); // Enderperlen-Cooldown gilt nur im Kampf
                p.sendMessage(plugin.msg("combat-end"));
            } else {
                long left = (end - now + 999) / 1000;
                p.sendActionBar(Component.text("⚔ Im Kampf: " + left + "s", NamedTextColor.RED));
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = attacker(e.getDamager());
        if (attacker != null) tag(attacker, victim);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProjectile(ProjectileHitEvent e) {
        if (e.getEntity() instanceof EnderPearl) return;
        if (e.getHitEntity() instanceof Player victim && e.getEntity().getShooter() instanceof Player shooter) {
            tag(shooter, victim);
        }
    }

    @EventHandler
    public void onLaunch(ProjectileLaunchEvent e) {
        if (e.getEntity() instanceof EnderPearl pearl && pearl.getShooter() instanceof Player p && isInCombat(p)) {
            int sec = plugin.getConfig().getInt("combat.enderpearl-cooldown", 15);
            if (sec > 0) {
                p.setCooldown(Material.ENDER_PEARL, sec * 20);
                p.sendMessage(plugin.msg("enderpearl-cooldown", "{seconds}", String.valueOf(sec)));
            }
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        until.remove(e.getEntity().getUniqueId());
        opponent.remove(e.getEntity().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        boolean fighting = isInCombat(p);
        UUID oppId = opponent.remove(p.getUniqueId());
        until.remove(p.getUniqueId());
        if (!fighting || e.getReason() == PlayerQuitEvent.QuitReason.KICKED) return;

        Bukkit.broadcast(plugin.msg("combat-log", "{player}", p.getName()));
        if (oppId != null) {
            Player opp = Bukkit.getPlayer(oppId);
            if (opp != null) p.setKiller(opp);
        }
        p.setHealth(0.0); // Tod mit Item-Drop, Killer bekommt die Belohnung
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!isInCombat(p)) return;
        String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (cmd.contains(":")) cmd = cmd.substring(cmd.indexOf(':') + 1);
        if (plugin.getConfig().getStringList("combat.blocked-commands").contains(cmd)) {
            e.setCancelled(true);
            p.sendMessage(plugin.msg("combat-blocked"));
        }
    }
}
