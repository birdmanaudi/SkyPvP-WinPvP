package de.skypvp;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Dauer-Parser: "30m", "12h", "2d", "1w", "1d12h", "perm". */
public final class TimeUtil {

    public static final long PERM = -1;
    public static final long INVALID = -2;
    private static final Pattern FULL = Pattern.compile("(?i)(\\d+[smhdw])+");
    private static final Pattern PART = Pattern.compile("(?i)(\\d+)([smhdw])");

    private TimeUtil() {
    }

    /** @return Millisekunden, PERM (-1) für permanent oder INVALID (-2). */
    public static long parse(String s) {
        if (s == null) return INVALID;
        s = s.trim().toLowerCase(Locale.ROOT);
        if (s.equals("perm") || s.equals("permanent") || s.equals("lifetime") || s.equals("unlimited")
                || s.equals("unendlich")) return PERM;
        if (!FULL.matcher(s).matches()) return INVALID;
        long total = 0;
        Matcher m = PART.matcher(s);
        while (m.find()) {
            long n;
            try {
                n = Long.parseLong(m.group(1));
            } catch (NumberFormatException e) {
                return INVALID;
            }
            long unit = switch (m.group(2).charAt(0)) {
                case 's' -> 1000L;
                case 'm' -> 60_000L;
                case 'h' -> 3_600_000L;
                case 'd' -> 86_400_000L;
                default -> 604_800_000L;
            };
            total += n * unit;
            if (total > 3_650L * 86_400_000L) total = 3_650L * 86_400_000L; // max. 10 Jahre
        }
        return total <= 0 ? INVALID : total;
    }

    public static String format(long ms) {
        if (ms < 0) return "Permanent";
        long s = ms / 1000;
        long d = s / 86400;
        s %= 86400;
        long h = s / 3600;
        s %= 3600;
        long m = s / 60;
        s %= 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append(d == 1 ? " Tag " : " Tage ");
        if (h > 0) sb.append(h).append(" Std ");
        if (m > 0) sb.append(m).append(" Min ");
        if (sb.length() == 0) sb.append(Math.max(s, 1)).append(" Sek");
        return sb.toString().trim();
    }
}
