package de.skypvp;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * /hilfe: zeigt alle Befehle, die der Spieler nutzen darf – nach Rängen gruppiert (help.* in der config.yml).
 * Ein Abschnitt wird gezeigt, wenn der Rang des Spielers (oder ein geerbter Rang) in "show-for" steht.
 * Wer das Recht skypvp.help.all hat (Admin), sieht alle Abschnitte.
 */
public class HelpManager implements CommandExecutor, Listener {

    private final SkyPvPPlugin plugin;

    public HelpManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean chainHas(RankManager.Rank rank, String id, Set<String> seen) {
        if (rank == null || !seen.add(rank.id())) return false;
        if (rank.id().equals(id)) return true;
        for (String parent : rank.inherits()) {
            if (chainHas(plugin.ranks().byId(parent), id, seen)) return true;
        }
        return false;
    }

    private boolean visible(CommandSender sender, ConfigurationSection section) {
        if (!(sender instanceof Player p)) return true;
        if (p.hasPermission("skypvp.help.all")) return true;
        RankManager.Rank rank = plugin.ranks().getRank(p.getUniqueId());
        for (String id : section.getStringList("show-for")) {
            if (chainHas(rank, id.toLowerCase(Locale.ROOT), new HashSet<>())) return true;
        }
        return false;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        for (String line : plugin.getConfig().getStringList("help.header")) sender.sendMessage(Text.legacy(line));

        ConfigurationSection sections = plugin.getConfig().getConfigurationSection("help.sections");
        if (sections != null) {
            for (String key : sections.getKeys(false)) {
                ConfigurationSection s = sections.getConfigurationSection(key);
                if (s == null || !visible(sender, s)) continue;
                sender.sendMessage(Text.legacy(s.getString("title", key)));
                for (String c : s.getStringList("commands")) {
                    sender.sendMessage(Text.legacy(" &8» " + c));
                }
            }
        }

        for (String line : plugin.getConfig().getStringList("help.footer")) sender.sendMessage(Text.legacy(line));
        return true;
    }

    /** /help und /? zeigen ebenfalls die schöne Hilfe (abschaltbar mit help.override-help: false). */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommandPreprocess(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("help.override-help", true)) return;
        String m = e.getMessage().toLowerCase(Locale.ROOT).trim();
        if (m.equals("/help") || m.startsWith("/help ") || m.equals("/?") || m.equals("/minecraft:help")) {
            e.setMessage("/hilfe");
        }
    }
}
