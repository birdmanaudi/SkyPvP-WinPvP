package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Trophäen-Köpfe: Beim Kill bekommt der Killer den Kopf des Opfers (pro Killer und Opfer nur einmal).
 *  /trophy sell            alle Köpfe im Inventar gegen Gold tauschen
 *  /trophy reset <Spieler|all>   Sperre zurücksetzen (Team)
 */
public class TrophyManager implements CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;
    private final NamespacedKey key;
    private final File file;
    private final Map<UUID, Set<UUID>> collected = new HashMap<>();

    public TrophyManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "trophy");
        this.file = new File(plugin.getDataFolder(), "trophies.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = c.getConfigurationSection("collected");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                Set<UUID> set = new HashSet<>();
                for (String v : sec.getStringList(k)) {
                    try {
                        set.add(UUID.fromString(v));
                    } catch (IllegalArgumentException ignored) {
                    }
                }
                try {
                    collected.put(UUID.fromString(k), set);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Map.Entry<UUID, Set<UUID>> e : collected.entrySet()) {
            List<String> list = new ArrayList<>();
            for (UUID u : e.getValue()) list.add(u.toString());
            c.set("collected." + e.getKey(), list);
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("trophies.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    private ItemStack head(Player victim) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(victim);
        meta.displayName(Text.legacy(plugin.getConfig().getString("trophy.name", "&6Kopf von &f{player}")
                .replace("{player}", victim.getName())).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String l : plugin.getConfig().getStringList("trophy.lore")) {
            lore.add(Text.legacy(l).decoration(TextDecoration.ITALIC, false));
        }
        if (!lore.isEmpty()) meta.lore(lore);
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        head.setItemMeta(meta);
        return head;
    }

    private boolean isTrophy(ItemStack s) {
        return s != null && s.getType() == Material.PLAYER_HEAD && s.hasItemMeta()
                && s.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    /** Gibt dem Killer den Kopf des Opfers (falls noch nicht erhalten). */
    public boolean award(Player killer, Player victim) {
        if (!plugin.getConfig().getBoolean("trophy.enabled", true)) return false;
        if (plugin.getConfig().getBoolean("trophy.once-per-victim", true)) {
            Set<UUID> set = collected.computeIfAbsent(killer.getUniqueId(), k -> new HashSet<>());
            if (!set.add(victim.getUniqueId())) return false;
            save();
        }
        CurrencyManager.giveItem(killer, head(victim));
        killer.sendMessage(plugin.msg("trophy-received", "{player}", victim.getName()));
        return true;
    }

    private void sell(Player p) {
        int heads = 0;
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            if (isTrophy(contents[i])) {
                heads += contents[i].getAmount();
                p.getInventory().setItem(i, null);
            }
        }
        if (heads == 0) {
            p.sendMessage(plugin.msg("trophy-none"));
            return;
        }
        int total = heads * Math.max(1, plugin.getConfig().getInt("trophy.sell-value", 3));
        CurrencyManager.giveValue(p, total);
        p.sendMessage(plugin.msg("trophy-sold", "{count}", String.valueOf(heads), "{amount}", String.valueOf(total)));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("sell")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(plugin.msg("player-only"));
                return true;
            }
            sell(p);
            return true;
        }
        if (sub.equals("reset")) {
            if (!sender.hasPermission("skypvp.trophy.reset")) {
                sender.sendMessage(plugin.msg("no-permission"));
                return true;
            }
            if (args.length != 2) {
                sender.sendMessage(plugin.msg("usage-trophy"));
                return true;
            }
            if (args[1].equalsIgnoreCase("all")) {
                collected.clear();
                save();
                sender.sendMessage(plugin.msg("trophy-reset-all"));
                return true;
            }
            OfflinePlayer t = Bukkit.getPlayerExact(args[1]);
            if (t == null) t = Bukkit.getOfflinePlayerIfCached(args[1]);
            if (t == null) {
                sender.sendMessage(plugin.msg("player-not-found", "{player}", args[1]));
                return true;
            }
            collected.remove(t.getUniqueId());
            save();
            sender.sendMessage(plugin.msg("trophy-reset", "{player}", t.getName() != null ? t.getName() : args[1]));
            return true;
        }
        sender.sendMessage(plugin.msg("usage-trophy"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("sell"));
            if (sender.hasPermission("skypvp.trophy.reset")) subs.add("reset");
            for (String s : subs) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("reset") && sender.hasPermission("skypvp.trophy.reset")) {
            if ("all".startsWith(start)) out.add("all");
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
            }
        }
        return out;
    }
}
