package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Item;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Entfernt in festen Abständen am Boden liegende Items (mit Vorwarnung). Einstellungen: itemcleaner.* */
public class ItemCleaner implements CommandExecutor {

    private final SkyPvPPlugin plugin;
    private long nextClean;
    private final Set<Long> warned = new HashSet<>();

    public ItemCleaner(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        reset();
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private long intervalMs() {
        long ms = TimeUtil.parse(plugin.getConfig().getString("itemcleaner.interval", "5m"));
        return ms > 0 ? ms : 300_000L;
    }

    private void reset() {
        long interval = intervalMs();
        nextClean = System.currentTimeMillis() + interval;
        warned.clear();
        for (String raw : plugin.getConfig().getStringList("itemcleaner.warn-at")) {
            long ms = TimeUtil.parse(raw);
            if (ms >= interval) warned.add(ms / 1000);
        }
    }

    private void tick() {
        if (!plugin.getConfig().getBoolean("itemcleaner.enabled", true)) return;
        long rem = nextClean - System.currentTimeMillis();
        if (rem <= 0) {
            int n = clean();
            Bukkit.broadcast(plugin.msg("cleaner-done", "{count}", String.valueOf(n)));
            reset();
            return;
        }
        long remSec = (rem + 999) / 1000;
        for (String raw : plugin.getConfig().getStringList("itemcleaner.warn-at")) {
            long ms = TimeUtil.parse(raw);
            if (ms <= 0) continue;
            long s = ms / 1000;
            if (remSec <= s && warned.add(s)) {
                Bukkit.broadcast(plugin.msg("cleaner-warn", "{time}", TimeUtil.format(s * 1000)));
            }
        }
    }

    /** Entfernt alle (alt genug, nicht geschützten) Item-Entities. @return Anzahl */
    public int clean() {
        long minAgeTicks = Math.max(0, plugin.getConfig().getInt("itemcleaner.min-age-seconds", 5)) * 20L;
        List<String> worlds = plugin.getConfig().getStringList("itemcleaner.worlds");
        List<String> keep = plugin.getConfig().getStringList("itemcleaner.keep");
        int count = 0;
        for (World w : Bukkit.getWorlds()) {
            if (!worlds.isEmpty() && !worlds.contains(w.getName())) continue;
            for (Item item : w.getEntitiesByClass(Item.class)) {
                if (item.getTicksLived() < minAgeTicks) continue;
                if (keep.contains(item.getItemStack().getType().name())) continue;
                item.remove();
                count++;
            }
        }
        return count;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        int n = clean();
        Bukkit.broadcast(plugin.msg("cleaner-done", "{count}", String.valueOf(n)));
        reset();
        return true;
    }
}
