package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * 1.8-PvP auf der neuen Version (Abschnitt "oldpvp" in der config.yml):
 *  - kein Angriffs-Cooldown (Angriffstempo hoch gesetzt)
 *  - kein Schwert-Fegen
 *  - 1.8-Schwertschaden (Bonus einstellbar)
 *  - verzauberter Goldapfel wie in 1.8 (Regeneration V, 30 Sekunden)
 * Nicht möglich: Blocken mit dem Schwert (gibt es in neuen Versionen nicht mehr).
 */
public class OldPvPManager implements Listener {

    private final SkyPvPPlugin plugin;
    private Attribute attackSpeed;

    public OldPvPManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.attackSpeed = lookup();
        Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 20L, 100L);
    }

    private Attribute lookup() {
        for (String key : new String[]{"attack_speed", "generic.attack_speed"}) {
            Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(key));
            if (a != null) return a;
        }
        plugin.getLogger().warning("Angriffstempo-Attribut nicht gefunden - 1.8-PvP ohne Cooldown-Entfernung.");
        return null;
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("oldpvp.enabled", true);
    }

    private void apply(Player p) {
        if (attackSpeed == null) return;
        AttributeInstance inst = p.getAttribute(attackSpeed);
        if (inst == null) return;
        double wanted = enabled() ? plugin.getConfig().getDouble("oldpvp.attack-speed", 16.0) : inst.getDefaultValue();
        if (inst.getBaseValue() != wanted) inst.setBaseValue(wanted);
    }

    private void refreshAll() {
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
    }

    /** Beim Abschalten des Plugins das normale Angriffstempo wiederherstellen. */
    public void shutdown() {
        if (attackSpeed == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            AttributeInstance inst = p.getAttribute(attackSpeed);
            if (inst != null) inst.setBaseValue(inst.getDefaultValue());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        apply(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> apply(p));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!enabled()) return;
        if (e.getCause() == EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK
                && plugin.getConfig().getBoolean("oldpvp.disable-sweep", true)) {
            e.setCancelled(true);
            return;
        }
        if (e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK && e.getDamager() instanceof Player p) {
            double bonus = plugin.getConfig().getDouble("oldpvp.sword-damage-bonus", 1.0);
            Material m = p.getInventory().getItemInMainHand().getType();
            if (bonus != 0 && m.name().endsWith("_SWORD")) {
                e.setDamage(Math.max(0, e.getDamage() + bonus));
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        if (!enabled() || !plugin.getConfig().getBoolean("oldpvp.notch-apple.enabled", true)) return;
        if (e.getItem().getType() != Material.ENCHANTED_GOLDEN_APPLE) return;
        Player p = e.getPlayer();
        // einen Tick später, damit unsere Werte die neuen Standard-Effekte ersetzen
        Bukkit.getScheduler().runTask(plugin, () -> {
            var c = plugin.getConfig();
            p.removePotionEffect(PotionEffectType.REGENERATION);
            p.removePotionEffect(PotionEffectType.ABSORPTION);
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,
                    c.getInt("oldpvp.notch-apple.regeneration-seconds", 30) * 20,
                    Math.max(0, c.getInt("oldpvp.notch-apple.regeneration-level", 5) - 1)));
            p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION,
                    c.getInt("oldpvp.notch-apple.absorption-seconds", 120) * 20,
                    Math.max(0, c.getInt("oldpvp.notch-apple.absorption-level", 1) - 1)));
        });
    }
}
