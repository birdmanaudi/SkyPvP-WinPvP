package de.skypvp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Goldregen-Airdrop: In zufälligen Abständen erscheint eine Loot-Kiste im festgelegten Gebiet,
 * die Koordinaten werden im Chat angesagt.
 *  /airdrop setarea [Radius]   Gebiet = deine Position (Mitte) + Radius
 *  /airdrop now                sofort einen Drop auslösen
 */
public class AirdropManager implements Listener, CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;
    private final File file;
    private final Random rnd = new Random();
    private Location center;
    private double radius;
    private Block active;
    private long despawnAt;
    private long nextAt;

    public AirdropManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "airdrop.yml");
        this.radius = plugin.getConfig().getDouble("airdrop.radius", 40);
        load();
        scheduleNext();
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        World w = Bukkit.getWorld(c.getString("world", ""));
        if (w == null) return;
        center = new Location(w, c.getDouble("x"), c.getDouble("y"), c.getDouble("z"));
        radius = c.getDouble("radius", radius);
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        c.set("world", center.getWorld().getName());
        c.set("x", center.getX());
        c.set("y", center.getY());
        c.set("z", center.getZ());
        c.set("radius", radius);
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("airdrop.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    private void scheduleNext() {
        long min = TimeUtil.parse(plugin.getConfig().getString("airdrop.min-interval", "30m"));
        long max = TimeUtil.parse(plugin.getConfig().getString("airdrop.max-interval", "60m"));
        if (min <= 0) min = 1_800_000L;
        if (max < min) max = min;
        nextAt = System.currentTimeMillis() + min + (long) (rnd.nextDouble() * (max - min));
    }

    private static boolean same(Block a, Block b) {
        return a != null && b != null && a.getWorld().equals(b.getWorld())
                && a.getX() == b.getX() && a.getY() == b.getY() && a.getZ() == b.getZ();
    }

    private void tick() {
        long now = System.currentTimeMillis();
        if (active != null) {
            beam();
            if (despawnAt > 0 && now >= despawnAt) {
                removeChest();
                Bukkit.broadcast(plugin.msg("airdrop-despawn"));
            }
            return;
        }
        if (!plugin.getConfig().getBoolean("airdrop.enabled", true) || center == null) return;
        if (now < nextAt) return;
        if (Bukkit.getOnlinePlayers().size() < plugin.getConfig().getInt("airdrop.min-players", 2)) {
            nextAt = now + 60_000L;
            return;
        }
        if (drop()) scheduleNext(); else nextAt = now + 60_000L;
    }

    private void beam() {
        World w = active.getWorld();
        for (int i = 1; i <= 30; i += 2) {
            w.spawnParticle(Particle.END_ROD, active.getX() + 0.5, active.getY() + i, active.getZ() + 0.5, 1, 0, 0, 0, 0);
        }
    }

    private Block findSpot() {
        World w = center.getWorld();
        int up = plugin.getConfig().getInt("airdrop.height-up", 15);
        int down = plugin.getConfig().getInt("airdrop.height-down", 40);
        for (int attempt = 0; attempt < 40; attempt++) {
            double ang = rnd.nextDouble() * 2 * Math.PI;
            double dist = Math.sqrt(rnd.nextDouble()) * radius;
            int x = (int) Math.floor(center.getX() + Math.cos(ang) * dist);
            int z = (int) Math.floor(center.getZ() + Math.sin(ang) * dist);
            int top = center.getBlockY() + up;
            int bottom = Math.max(w.getMinHeight() + 1, center.getBlockY() - down);
            for (int y = top; y >= bottom; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (b.getType().isSolid() && b.getRelative(BlockFace.UP).isEmpty()) {
                    Block spot = b.getRelative(BlockFace.UP);
                    if (plugin.spawn().isInSpawn(spot.getLocation())) break; // nicht auf der Spawn-Insel
                    return spot;
                }
            }
        }
        return null;
    }

    /** Löst einen Airdrop aus. @return false, wenn kein Platz gefunden wurde oder schon einer liegt. */
    public boolean drop() {
        if (center == null || center.getWorld() == null || active != null) return false;
        Block spot = findSpot();
        if (spot == null) return false;
        spot.setType(Material.CHEST);
        if (!(spot.getState() instanceof Chest chest)) {
            spot.setType(Material.AIR);
            return false;
        }
        chest.customName(Text.legacy(plugin.getConfig().getString("airdrop.title", "&6&lGoldregen")));
        chest.update();
        Inventory inv = chest.getBlockInventory();
        for (String line : plugin.getConfig().getStringList("airdrop.items")) {
            ItemStack it = ItemUtil.parse(line);
            if (it != null) inv.addItem(it);
        }
        active = spot;
        long ms = TimeUtil.parse(plugin.getConfig().getString("airdrop.despawn", "10m"));
        despawnAt = ms > 0 ? System.currentTimeMillis() + ms : 0;

        spot.getWorld().strikeLightningEffect(spot.getLocation().add(0.5, 0, 0.5));
        for (Player p : Bukkit.getOnlinePlayers()) p.playSound(p.getLocation(), Sound.BLOCK_BELL_USE, 1f, 1f);
        String time = ms > 0 ? TimeUtil.format(ms) : plugin.getConfig().getString("messages.unlimited", "bis auf Weiteres");
        for (Component c : plugin.msgLines("airdrop-announce", "{x}", String.valueOf(spot.getX()),
                "{y}", String.valueOf(spot.getY()), "{z}", String.valueOf(spot.getZ()), "{time}", time)) {
            Bukkit.broadcast(c);
        }
        return true;
    }

    private void removeChest() {
        if (active == null) return;
        if (active.getState() instanceof Chest c) c.getBlockInventory().clear();
        active.setType(Material.AIR);
        active = null;
    }

    /** Beim Herunterfahren: Kiste entfernen, damit nichts übrig bleibt. */
    public void cleanup() {
        removeChest();
    }

    private static boolean isEmpty(Inventory inv) {
        for (ItemStack it : inv.getContents()) if (it != null && !it.getType().isAir()) return false;
        return true;
    }

    // ------------------------------------------------------------------ Ereignisse

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (active == null) return;
        if (!(e.getInventory().getHolder() instanceof Chest c) || !same(c.getBlock(), active)) return;
        if (isEmpty(e.getInventory())) {
            removeChest();
            Bukkit.broadcast(plugin.msg("airdrop-looted", "{player}", e.getPlayer().getName()));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (active == null || !same(e.getBlock(), active)) return;
        if (e.getPlayer().hasPermission("skypvp.airdrop.manage")) {
            active = null; // Team hat die Kiste bewusst abgebaut
        } else {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        if (active != null) e.blockList().removeIf(b -> same(b, active));
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        if (active != null) e.blockList().removeIf(b -> same(b, active));
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "setarea" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage(plugin.msg("player-only"));
                    return true;
                }
                double r = plugin.getConfig().getDouble("airdrop.radius", 40);
                if (args.length >= 2) {
                    try {
                        r = Double.parseDouble(args[1]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(plugin.msg("usage-airdrop"));
                        return true;
                    }
                }
                radius = Math.max(5, Math.min(300, r));
                center = p.getLocation();
                save();
                p.sendMessage(plugin.msg("airdrop-set", "{radius}", String.valueOf((int) radius)));
            }
            case "now" -> {
                if (center == null) {
                    sender.sendMessage(plugin.msg("airdrop-no-area"));
                    return true;
                }
                if (!drop()) sender.sendMessage(plugin.msg("airdrop-failed"));
            }
            default -> sender.sendMessage(plugin.msg("usage-airdrop"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("setarea", "now")) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
