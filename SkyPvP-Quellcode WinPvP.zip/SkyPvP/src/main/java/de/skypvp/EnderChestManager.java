package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Eigene Enderchest (max. 54 Slots). Wie viele Slots frei sind, hängt vom Rang ab
 * (ranks.<rang>.enderchest-slots in der config.yml). Nicht freigeschaltete Slots zeigen Barrieren.
 */
public class EnderChestManager implements Listener, CommandExecutor {

    private static final int SIZE = 54;

    public static class Holder implements InventoryHolder {
        final UUID owner;
        final int allowed;
        Inventory inventory;

        Holder(UUID owner, int allowed) {
            this.owner = owner;
            this.allowed = allowed;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final SkyPvPPlugin plugin;
    private final File folder;
    private final Map<UUID, Inventory> open = new HashMap<>();

    public EnderChestManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "enderchests");
        this.folder.mkdirs();
    }

    public int slotsFor(Player p) {
        int s = plugin.ranks().getRank(p.getUniqueId()).enderchestSlots();
        return Math.max(1, Math.min(SIZE, s));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (plugin.combat().isInCombat(p)) {
            p.sendMessage(plugin.msg("combat-blocked"));
            return true;
        }
        open(p);
        return true;
    }

    private ItemStack lockedItem() {
        ItemStack it = new ItemStack(Material.BARRIER);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Text.legacy(plugin.getConfig().getString("enderchest.locked-name", "&cGesperrt"))
                .decoration(TextDecoration.ITALIC, false));
        it.setItemMeta(meta);
        return it;
    }

    public void open(Player p) {
        int allowed = slotsFor(p);
        Holder holder = new Holder(p.getUniqueId(), allowed);
        Inventory inv = Bukkit.createInventory(holder, SIZE, Component.text("Enderchest", NamedTextColor.DARK_PURPLE));
        holder.inventory = inv;
        load(p, inv, allowed);
        for (int i = allowed; i < SIZE; i++) inv.setItem(i, lockedItem());
        open.put(p.getUniqueId(), inv);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1f);
    }

    @EventHandler
    public void onOpen(InventoryOpenEvent e) {
        if (e.getInventory().getType() != InventoryType.ENDER_CHEST) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        e.setCancelled(true);
        if (plugin.combat().isInCombat(p)) {
            p.sendMessage(plugin.msg("combat-blocked"));
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> open(p));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h) || h.allowed >= SIZE) return;
        if (e.getClickedInventory() != null && e.getClickedInventory().equals(top) && e.getSlot() >= h.allowed) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder h) || h.allowed >= SIZE) return;
        for (int raw : e.getRawSlots()) {
            if (raw < SIZE && raw >= h.allowed) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        save(h.owner, e.getInventory(), h.allowed);
        open.remove(h.owner);
        if (e.getPlayer() instanceof Player p) {
            p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_CLOSE, 0.8f, 1f);
        }
    }

    public void saveAll() {
        for (Map.Entry<UUID, Inventory> e : open.entrySet()) {
            if (e.getValue().getHolder() instanceof Holder h) save(e.getKey(), e.getValue(), h.allowed);
        }
    }

    private File file(UUID id) {
        return new File(folder, id + ".yml");
    }

    private void load(Player p, Inventory inv, int allowed) {
        File f = file(p.getUniqueId());
        if (!f.exists()) {
            // Erstes Öffnen: Inhalt der alten 27-Slot-Enderchest übernehmen
            Inventory vanilla = p.getEnderChest();
            int slot = 0;
            for (ItemStack item : vanilla.getContents()) {
                if (item == null || item.getType().isAir()) continue;
                if (slot < allowed) {
                    inv.setItem(slot++, item);
                } else {
                    CurrencyManager.giveItem(p, item); // passt nicht mehr rein -> ins Inventar
                }
            }
            vanilla.clear();
            save(p.getUniqueId(), inv, allowed);
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection sec = cfg.getConfigurationSection("items");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                int slot = Integer.parseInt(key);
                ItemStack item = sec.getItemStack(key);
                if (slot >= 0 && slot < allowed && item != null) inv.setItem(slot, item);
            } catch (NumberFormatException ignored) {
            }
        }
    }

    /** Speichert nur die freigeschalteten Slots; Items in gesperrten Slots (z. B. nach Rang-Ablauf) bleiben erhalten. */
    private void save(UUID id, Inventory inv, int allowed) {
        File f = file(id);
        YamlConfiguration cfg = f.exists() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
        for (int i = 0; i < allowed; i++) {
            ItemStack item = inv.getItem(i);
            cfg.set("items." + i, item != null && !item.getType().isAir() ? item : null);
        }
        try {
            cfg.save(f);
        } catch (IOException ex) {
            plugin.getLogger().severe("Enderchest von " + id + " konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }
}
