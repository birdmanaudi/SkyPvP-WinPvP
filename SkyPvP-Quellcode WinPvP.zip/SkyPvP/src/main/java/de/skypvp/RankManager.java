package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RankManager {

    public record Rank(String id, String prefix, NamedTextColor color, int priority,
                       List<String> inherits, List<String> permissions, String maxTempban, String maxMute, int enderchestSlots) {
        public Component prefixComponent() {
            return Text.serializer().deserialize(prefix);
        }

        public String displayName() {
            return id.substring(0, 1).toUpperCase(Locale.ROOT) + id.substring(1);
        }

        /** -1 = unbegrenzt, 0 = darf nicht tempbannen, sonst Millisekunden. */
        public long maxTempbanMillis() {
            long t = TimeUtil.parse(maxTempban);
            return t == TimeUtil.INVALID ? 0 : t;
        }

        public long maxMuteMillis() {
            long t = TimeUtil.parse(maxMute);
            return t == TimeUtil.INVALID ? 0 : t;
        }
    }

    private final SkyPvPPlugin plugin;
    private final File dataFile;
    private final YamlConfiguration data;
    private final Map<String, Rank> ranks = new LinkedHashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final Map<UUID, Rank> cache = new ConcurrentHashMap<>();
    private String defaultRank = "spieler";

    public RankManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "players.yml");
        this.data = YamlConfiguration.loadConfiguration(dataFile);
        loadRanks();
    }

    public void loadRanks() {
        ranks.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("ranks");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection r = sec.getConfigurationSection(key);
                if (r == null) continue;
                String id = key.toLowerCase(Locale.ROOT);
                NamedTextColor color = NamedTextColor.NAMES.value(r.getString("color", "white").toLowerCase(Locale.ROOT));
                if (color == null) color = NamedTextColor.WHITE;
                ranks.put(id, new Rank(id, r.getString("prefix", ""), color, r.getInt("priority", 50),
                        r.getStringList("inherits"), r.getStringList("permissions"),
                        r.getString("max-tempban", "0"), r.getString("max-mute", "0"),
                        r.getInt("enderchest-slots", 27)));
            }
        }
        defaultRank = plugin.getConfig().getString("default-rank", "spieler").toLowerCase(Locale.ROOT);
    }

    public Collection<Rank> allRanks() {
        return ranks.values();
    }

    public Rank byId(String id) {
        return id == null ? null : ranks.get(id.toLowerCase(Locale.ROOT));
    }

    private Rank defaultRank() {
        Rank r = byId(defaultRank);
        return r != null ? r : new Rank("spieler", "&7", NamedTextColor.GRAY, 99, List.of(), List.of(), "0", "0", 27);
    }

    private Rank resolve(UUID uuid) {
        String id = data.getString("players." + uuid + ".rank", defaultRank);
        long exp = data.getLong("players." + uuid + ".expires", 0);
        if (exp > 0 && exp < System.currentTimeMillis()) return defaultRank();
        Rank r = byId(id);
        return r != null ? r : defaultRank();
    }

    /** Liefert nie null. Für Online-Spieler aus dem Cache (thread-sicher, z. B. für den Chat). */
    public Rank getRank(UUID uuid) {
        Rank cached = cache.get(uuid);
        return cached != null ? cached : resolve(uuid);
    }

    /** Ablaufzeitpunkt in ms, 0 = permanent. */
    public long expiresAt(UUID uuid) {
        return data.getLong("players." + uuid + ".expires", 0);
    }

    /** durationMillis <= 0 = permanent. */
    public void setRank(OfflinePlayer target, Rank rank, long durationMillis) {
        String base = "players." + target.getUniqueId();
        data.set(base + ".rank", rank.id());
        data.set(base + ".expires", durationMillis > 0 ? System.currentTimeMillis() + durationMillis : 0);
        if (target.getName() != null) data.set(base + ".name", target.getName());
        saveData();
        Player online = target.getPlayer();
        if (online != null) apply(online);
    }

    /** Wird jede Minute aufgerufen: abgelaufene Ränge zurücksetzen. */
    public void checkExpiry() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            long exp = expiresAt(p.getUniqueId());
            if (exp > 0 && exp < System.currentTimeMillis()) {
                data.set("players." + p.getUniqueId(), null);
                saveData();
                apply(p);
                p.sendMessage(plugin.msg("rank-expired"));
            }
        }
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("players.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    /** Wendet Rechte, Tablist-Eintrag und Nametag des Spielers an. */
    public void apply(Player p) {
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old != null) {
            try {
                p.removeAttachment(old);
            } catch (IllegalArgumentException ignored) {
            }
        }

        Rank rank = resolve(p.getUniqueId());
        cache.put(p.getUniqueId(), rank);

        Map<String, Boolean> perms = new LinkedHashMap<>();
        collect(rank, perms, new HashSet<>());

        PermissionAttachment att = p.addAttachment(plugin);
        for (Map.Entry<String, Boolean> e : perms.entrySet()) {
            att.setPermission(e.getKey(), e.getValue());
        }
        attachments.put(p.getUniqueId(), att);

        p.recalculatePermissions();
        p.updateCommands();
        updateDisplay(p, rank);
    }

    public void remove(Player p) {
        PermissionAttachment att = attachments.remove(p.getUniqueId());
        if (att != null) {
            try {
                p.removeAttachment(att);
            } catch (IllegalArgumentException ignored) {
            }
        }
        cache.remove(p.getUniqueId());
        for (Player viewer : Bukkit.getOnlinePlayers()) removeEntry(viewer.getScoreboard(), p);
        removeEntry(Bukkit.getScoreboardManager().getMainScoreboard(), p);
    }

    private void removeEntry(Scoreboard sb, Player p) {
        Team t = sb.getEntryTeam(p.getName());
        if (t != null) t.removeEntry(p.getName());
    }

    public void shutdown() {
        for (Player p : Bukkit.getOnlinePlayers()) remove(p);
    }

    private void collect(Rank rank, Map<String, Boolean> out, Set<String> visited) {
        if (!visited.add(rank.id())) return;
        for (String parent : rank.inherits()) {
            Rank pr = byId(parent);
            if (pr != null) collect(pr, out, visited);
        }
        for (String raw : rank.permissions()) {
            String node = raw.trim();
            boolean value = true;
            if (node.startsWith("-")) {
                value = false;
                node = node.substring(1);
            }
            if (node.equals("*")) {
                for (Permission perm : Bukkit.getPluginManager().getPermissions()) out.put(perm.getName(), value);
            } else if (node.endsWith(".*")) {
                String prefix = node.substring(0, node.length() - 1);
                for (Permission perm : Bukkit.getPluginManager().getPermissions()) {
                    if (perm.getName().startsWith(prefix)) out.put(perm.getName(), value);
                }
                out.put(node, value);
            } else {
                out.put(node, value);
            }
        }
    }

    private void updateDisplay(Player p, Rank rank) {
        // Jeder Spieler kann ein eigenes Scoreboard (Sidebar) haben -> Teams überall eintragen
        for (Player viewer : Bukkit.getOnlinePlayers()) applyTeam(viewer.getScoreboard(), p, rank);
        applyTeam(Bukkit.getScoreboardManager().getMainScoreboard(), p, rank);
        p.playerListName(rank.prefixComponent().append(Component.text(p.getName(), rank.color())));
    }

    /** Trägt alle Online-Spieler in das Scoreboard von viewer ein (Präfixe + Tablist-Sortierung). */
    public void syncScoreboard(Player viewer) {
        for (Player other : Bukkit.getOnlinePlayers()) {
            applyTeam(viewer.getScoreboard(), other, getRank(other.getUniqueId()));
        }
    }

    private void applyTeam(Scoreboard sb, Player p, Rank rank) {
        String teamName = String.format("%02d%s", Math.min(rank.priority(), 99), rank.id());
        if (teamName.length() > 16) teamName = teamName.substring(0, 16);

        Team team = sb.getTeam(teamName);
        if (team == null) team = sb.registerNewTeam(teamName);
        team.prefix(rank.prefixComponent());
        team.color(rank.color());

        Team current = sb.getEntryTeam(p.getName());
        if (current != null && !current.getName().equals(teamName)) current.removeEntry(p.getName());
        if (!team.hasEntry(p.getName())) team.addEntry(p.getName());
    }
}
