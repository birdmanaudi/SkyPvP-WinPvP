package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;

/** Spawn-Punkt + sicherer Bereich (Radius um den Spawn, kein PvP, kein Bauen, kein Schaden). */
public class SpawnManager implements Listener, CommandExecutor {

    private final SkyPvPPlugin plugin;
    private final File file;
    private Location spawn;
    private double radius;

    public SpawnManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "spawn.yml");
        this.radius = plugin.getConfig().getDouble("spawn.default-radius", 25);
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        World w = Bukkit.getWorld(c.getString("world", ""));
        if (w == null) return;
        spawn = new Location(w, c.getDouble("x"), c.getDouble("y"), c.getDouble("z"),
                (float) c.getDouble("yaw"), (float) c.getDouble("pitch"));
        radius = c.getDouble("radius", radius);
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        c.set("world", spawn.getWorld().getName());
        c.set("x", spawn.getX());
        c.set("y", spawn.getY());
        c.set("z", spawn.getZ());
        c.set("yaw", spawn.getYaw());
        c.set("pitch", spawn.getPitch());
        c.set("radius", radius);
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("spawn.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    public Location getSpawn() {
        return spawn != null ? spawn.clone() : Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    /** Geschützt = Spawn-Bereich ODER Event-Schutzzone. */
    public boolean isInSpawn(Location l) {
        return inMainSpawn(l)
                || (plugin.events() != null && plugin.events().isInSafeZone(l))
                || (plugin.arena() != null && plugin.arena().isInSafeZone(l));
    }

    private boolean inMainSpawn(Location l) {
        Location s = getSpawn();
        if (l.getWorld() == null || !l.getWorld().equals(s.getWorld())) return false;
        // Unterhalb der Spawn-Insel (Kampf-Etage) gilt der Schutz nicht mehr
        if (l.getY() < s.getY() - plugin.getConfig().getDouble("spawn.protect-below", 5)) return false;
        double dx = l.getX() - s.getX();
        double dz = l.getZ() - s.getZ();
        return dx * dx + dz * dz <= radius * radius;
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("setspawn")) {
            if (args.length == 1 && args[0].equalsIgnoreCase("show")) {
                showRing(p);
                return true;
            }
            double r = plugin.getConfig().getDouble("spawn.default-radius", 25);
            if (args.length >= 1) {
                try {
                    r = Double.parseDouble(args[0]);
                } catch (NumberFormatException ex) {
                    p.sendMessage(plugin.msg("usage-setspawn"));
                    return true;
                }
            }
            radius = Math.max(3, Math.min(500, r));
            spawn = p.getLocation();
            save();
            p.sendMessage(plugin.msg("spawn-set", "{radius}", String.valueOf((int) radius)));
            showRing(p);
            return true;
        }
        teleportToSpawn(p);
        return true;
    }

    private void teleportToSpawn(Player p) {
        if (plugin.combat().isInCombat(p)) {
            p.sendMessage(plugin.msg("combat-blocked"));
            return;
        }
        int delay = p.hasPermission("skypvp.spawn.instant") ? 0 : plugin.getConfig().getInt("spawn.teleport-delay", 3);
        if (delay <= 0) {
            p.teleport(getSpawn());
            return;
        }
        Location start = p.getLocation().getBlock().getLocation();
        p.sendMessage(plugin.msg("spawn-teleport", "{seconds}", String.valueOf(delay)));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            boolean moved = !p.getLocation().getBlock().getLocation().equals(start);
            if (moved || plugin.combat().isInCombat(p)) {
                p.sendMessage(plugin.msg("spawn-cancelled"));
                return;
            }
            p.teleport(getSpawn());
        }, delay * 20L);
    }

    private void showRing(Player p) {
        Location c = getSpawn();
        double r = radius;
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 30 || !p.isOnline()) {
                    cancel();
                    return;
                }
                for (int i = 0; i < 96; i++) {
                    double a = 2 * Math.PI * i / 96;
                    p.spawnParticle(Particle.END_ROD, c.getX() + Math.cos(a) * r, c.getY() + 1,
                            c.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0);
                }
            }
        }.runTaskTimer(plugin, 0L, 10L);
    }

    // ------------------------------------------------------------------ Ereignisse

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        e.setRespawnLocation(getSpawn());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (plugin.getConfig().getBoolean("spawn.teleport-on-join", true)) {
            e.getPlayer().teleport(getSpawn());
        }
    }

    /** Kein Schaden für Spieler im Spawn (außer Void/Kill-Befehl). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.VOID || c == EntityDamageEvent.DamageCause.KILL
                || c == EntityDamageEvent.DamageCause.SUICIDE) return;
        if (isInSpawn(p.getLocation())) e.setCancelled(true);
    }

    /** Kein Schlagen/Schießen aus dem Spawn heraus. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        Player attacker = CombatManager.attacker(e.getDamager());
        if (attacker != null && e.getEntity() instanceof Player && isInSpawn(attacker.getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player p && isInSpawn(p.getLocation())) e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (isInSpawn(e.getBlock().getLocation()) && !e.getPlayer().hasPermission("skypvp.spawn.build")) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (isInSpawn(e.getBlock().getLocation()) && !e.getPlayer().hasPermission("skypvp.spawn.build")) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (isInSpawn(e.getBlock().getLocation()) && !e.getPlayer().hasPermission("skypvp.spawn.build")) {
            e.setCancelled(true);
        }
    }
}
