package de.skypvp;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /kit <name>: Kits stehen komplett in der config.yml (Items, Verzauberungen, Cooldown, Recht). */
public class KitManager implements CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;
    private final File file;
    private final YamlConfiguration cooldowns;

    public KitManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "kit-cooldowns.yml");
        this.cooldowns = YamlConfiguration.loadConfiguration(file);
    }

    private String permissionOf(String kit) {
        return plugin.getConfig().getString("kits." + kit + ".permission", "skypvp.kit." + kit);
    }

    private boolean allowed(Player p, String kit) {
        return p.hasPermission(permissionOf(kit));
    }

    private List<String> available(Player p) {
        List<String> out = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("kits");
        if (sec == null) return out;
        for (String k : sec.getKeys(false)) if (allowed(p, k)) out.add(k);
        return out;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (args.length == 0) {
            List<String> list = available(p);
            p.sendMessage(plugin.msg("kit-list", "{kits}", list.isEmpty() ? "-" : String.join(", ", list)));
            return true;
        }

        String kit = args[0].toLowerCase(Locale.ROOT);
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("kits." + kit);
        if (sec == null) {
            p.sendMessage(plugin.msg("kit-unknown", "{kit}", args[0]));
            return true;
        }
        if (!allowed(p, kit)) {
            p.sendMessage(plugin.msg("kit-no-permission"));
            return true;
        }

        long cd = TimeUtil.parse(sec.getString("cooldown", "2d"));
        if (cd < 0) cd = 2 * 86_400_000L;
        String key = p.getUniqueId() + "." + kit;
        long left = cooldowns.getLong(key, 0) + cd - System.currentTimeMillis();
        if (left > 0 && !p.hasPermission("skypvp.kit.bypass")) {
            p.sendMessage(plugin.msg("kit-cooldown", "{time}", TimeUtil.format(left)));
            return true;
        }

        for (String line : sec.getStringList("items")) {
            ItemStack item = parse(line);
            if (item == null) {
                plugin.getLogger().warning("Kit '" + kit + "': ungültige Zeile '" + line + "'");
                continue;
            }
            CurrencyManager.giveItem(p, item);
        }

        cooldowns.set(key, System.currentTimeMillis());
        try {
            cooldowns.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("kit-cooldowns.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
        p.sendMessage(plugin.msg("kit-received", "{kit}", kit));
        return true;
    }

    /** Gibt die Items eines Kits ohne Cooldown-Prüfung (z. B. als Vote-Belohnung). @return false, wenn es das Kit nicht gibt. */
    public boolean giveItems(Player p, String kit) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("kits." + kit.toLowerCase(Locale.ROOT));
        if (sec == null) return false;
        for (String line : sec.getStringList("items")) {
            ItemStack item = ItemUtil.parse(line);
            if (item != null) CurrencyManager.giveItem(p, item);
        }
        return true;
    }

    /** Zeilenformat: "MATERIAL MENGE ENCHANT:STUFE ENCHANT:STUFE ..." */
    private ItemStack parse(String line) {
        String[] t = line.trim().split("\\s+");
        if (t.length == 0) return null;
        Material m = Material.matchMaterial(t[0]);
        if (m == null || !m.isItem() || m.isAir()) return null;
        int amount = 1;
        if (t.length > 1) {
            try {
                amount = Integer.parseInt(t[1]);
            } catch (NumberFormatException ex) {
                return null;
            }
        }
        ItemStack item = new ItemStack(m, Math.max(1, amount));
        for (int i = 2; i < t.length; i++) {
            String[] e = t[i].split(":");
            if (e.length != 2) continue;
            Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(e[0].toLowerCase(Locale.ROOT)));
            if (ench == null) continue;
            try {
                item.addUnsafeEnchantment(ench, Integer.parseInt(e[1]));
            } catch (NumberFormatException ignored) {
            }
        }
        return item;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1 && sender instanceof Player p) {
            for (String k : available(p)) if (k.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(k);
        }
        return out;
    }
}
