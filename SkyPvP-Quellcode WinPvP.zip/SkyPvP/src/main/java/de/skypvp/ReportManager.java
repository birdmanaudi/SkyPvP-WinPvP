package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;

/** /report <Spieler> <Grund> (max. X pro Tag) und /reports für das Team. */
public class ReportManager implements CommandExecutor {

    private final SkyPvPPlugin plugin;
    private final File file;
    private final YamlConfiguration cfg;

    public ReportManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "reports.yml");
        this.cfg = YamlConfiguration.loadConfiguration(file);
    }

    private void save() {
        try {
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("reports.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("reports")) return handleList(sender, args);

        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (args.length < 2) {
            p.sendMessage(plugin.msg("usage-report"));
            return true;
        }
        OfflinePlayer target = Bukkit.getPlayerExact(args[0]);
        if (target == null) target = Bukkit.getOfflinePlayerIfCached(args[0]);
        if (target == null) {
            p.sendMessage(plugin.msg("player-not-found", "{player}", args[0]));
            return true;
        }
        if (target.getUniqueId().equals(p.getUniqueId())) {
            p.sendMessage(plugin.msg("report-self"));
            return true;
        }

        int max = plugin.getConfig().getInt("report.max-per-day", 2);
        String today = LocalDate.now().toString();
        String base = "daily." + p.getUniqueId();
        int count = today.equals(cfg.getString(base + ".date")) ? cfg.getInt(base + ".count") : 0;
        if (count >= max) {
            p.sendMessage(plugin.msg("report-limit", "{max}", String.valueOf(max)));
            return true;
        }
        cfg.set(base + ".date", today);
        cfg.set(base + ".count", count + 1);

        String reason = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        int id = cfg.getInt("next-id", 1);
        cfg.set("next-id", id + 1);
        String r = "reports." + id;
        cfg.set(r + ".reporter", p.getName());
        cfg.set(r + ".target", target.getName() != null ? target.getName() : args[0]);
        cfg.set(r + ".reason", reason);
        cfg.set(r + ".time", System.currentTimeMillis());
        cfg.set(r + ".open", true);
        save();

        p.sendMessage(plugin.msg("report-sent", "{player}", args[0]));
        plugin.discord().send("report", "Neuer Report #" + id, "**Reporter:** " + p.getName()
                + "\n**Gemeldet:** " + args[0] + "\n**Grund:** " + reason, DiscordManager.RED);
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("skypvp.report.view")) {
                staff.sendMessage(plugin.msg("report-notify", "{id}", String.valueOf(id), "{reporter}", p.getName(),
                        "{player}", args[0], "{reason}", reason));
            }
        }
        return true;
    }

    private boolean handleList(CommandSender sender, String[] args) {
        if (!sender.hasPermission("skypvp.report.view")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("close")) {
            String r = "reports." + args[1];
            if (!cfg.getBoolean(r + ".open", false)) {
                sender.sendMessage(plugin.msg("report-not-found"));
                return true;
            }
            cfg.set(r + ".open", false);
            cfg.set(r + ".closed-by", sender.getName());
            save();
            sender.sendMessage(plugin.msg("report-closed", "{id}", args[1]));
            return true;
        }
        ConfigurationSection sec = cfg.getConfigurationSection("reports");
        int shown = 0;
        if (sec != null) {
            sender.sendMessage(plugin.msg("reports-header"));
            for (String id : sec.getKeys(false)) {
                ConfigurationSection r = sec.getConfigurationSection(id);
                if (r == null || !r.getBoolean("open")) continue;
                sender.sendMessage(plugin.msg("report-notify", "{id}", id, "{reporter}", r.getString("reporter", "?"),
                        "{player}", r.getString("target", "?"), "{reason}", r.getString("reason", "")));
                if (++shown >= 10) break;
            }
        }
        if (shown == 0) sender.sendMessage(plugin.msg("reports-empty"));
        return true;
    }
}
