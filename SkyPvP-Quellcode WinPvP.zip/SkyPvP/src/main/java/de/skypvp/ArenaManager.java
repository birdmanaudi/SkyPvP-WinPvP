package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Arena für 1 gegen 1, 5 gegen 5 oder wie die Spieler wollen.
 *   /arena                                   zur Arena teleportieren
 *   /arena setspawn [Schutzradius] [Gebietsradius]
 *        Spawn der Arena = deine Position. Schutzradius = kleine Schutzzone um den Spawn (kein PvP/Schaden),
 *        Gebietsradius = ganze Arena (dort sind Enderperlen verboten).
 */
public class ArenaManager implements CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;
    private final File file;
    private Location spawn;
    private double protectRadius;
    private double areaRadius;

    public ArenaManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "arena.yml");
        this.protectRadius = plugin.getConfig().getDouble("arena.protect-radius", 5);
        this.areaRadius = plugin.getConfig().getDouble("arena.area-radius", 40);
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        World w = Bukkit.getWorld(c.getString("world", ""));
        if (w == null) return;
        spawn = new Location(w, c.getDouble("x"), c.getDouble("y"), c.getDouble("z"),
                (float) c.getDouble("yaw"), (float) c.getDouble("pitch"));
        protectRadius = c.getDouble("protect-radius", protectRadius);
        areaRadius = c.getDouble("area-radius", areaRadius);
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        c.set("world", spawn.getWorld().getName());
        c.set("x", spawn.getX());
        c.set("y", spawn.getY());
        c.set("z", spawn.getZ());
        c.set("yaw", spawn.getYaw());
        c.set("pitch", spawn.getPitch());
        c.set("protect-radius", protectRadius);
        c.set("area-radius", areaRadius);
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("arena.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    private boolean within(Location l, double radius, double maxHeightDiff) {
        if (spawn == null || l == null || l.getWorld() == null || !l.getWorld().equals(spawn.getWorld())) return false;
        if (Math.abs(l.getY() - spawn.getY()) > maxHeightDiff) return false;
        double dx = l.getX() - spawn.getX();
        double dz = l.getZ() - spawn.getZ();
        return dx * dx + dz * dz <= radius * radius;
    }

    /** Kleine Schutzzone um den Arena-Spawn (kein PvP, kein Schaden). */
    public boolean isInSafeZone(Location l) {
        return within(l, protectRadius, 20);
    }

    /** Ganze Arena: hier sind Enderperlen verboten. */
    public boolean isInPearlZone(Location l) {
        return within(l, areaRadius, 80);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("setspawn")) {
            if (!p.hasPermission("skypvp.arena.manage")) {
                p.sendMessage(plugin.msg("no-permission"));
                return true;
            }
            double protect = plugin.getConfig().getDouble("arena.protect-radius", 5);
            double area = plugin.getConfig().getDouble("arena.area-radius", 40);
            try {
                if (args.length >= 2) protect = Double.parseDouble(args[1]);
                if (args.length >= 3) area = Double.parseDouble(args[2]);
            } catch (NumberFormatException ex) {
                p.sendMessage(plugin.msg("usage-arena"));
                return true;
            }
            protectRadius = Math.max(1, Math.min(100, protect));
            areaRadius = Math.max(protectRadius, Math.min(300, area));
            spawn = p.getLocation();
            save();
            p.sendMessage(plugin.msg("arena-set", "{protect}", String.valueOf((int) protectRadius),
                    "{area}", String.valueOf((int) areaRadius)));
            return true;
        }

        if (spawn == null) {
            p.sendMessage(plugin.msg("arena-no-spawn"));
            return true;
        }
        if (plugin.combat().isInCombat(p)) {
            p.sendMessage(plugin.msg("combat-blocked"));
            return true;
        }
        p.teleport(spawn.clone());
        p.sendMessage(plugin.msg("arena-joined"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1 && sender.hasPermission("skypvp.arena.manage")
                && "setspawn".startsWith(args[0].toLowerCase(Locale.ROOT))) {
            out.add("setspawn");
        }
        return out;
    }
}
