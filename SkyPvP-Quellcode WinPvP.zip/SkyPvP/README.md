# WinPvP.de – SkyPvP-Plugin

## Ohne PC bauen (nur Smartphone)
Siehe Anleitung im Chat: ZIP-Datei bei GitHub hochladen + build.yml anlegen -> GitHub baut die fertige SkyPvP.jar.

## Mit PC bauen
JDK 25 + Maven: `mvn package` -> `target/SkyPvP.jar` in den `plugins`-Ordner.
Zielversion: Paper 26.3 (Java 25). Läuft der Server auf einer anderen Version, Version in der pom.xml anpassen.

## Neu in 1.5.0
`/hilfe` (nach Rängen), Server-Liste mit Spielern/Event/Wartung, `/chatmute`, Schilder mit WinPvP-Kopfzeile,
Creator-Rang (`/creator`), 1.8-PvP (Abschnitt `oldpvp`), `/arena`, Enderperlen-Sperre (`/region flag <Name> enderpearl deny`),
Rundmeldung alle 15 Minuten. **Alte config.yml vor dem Update löschen** (neue wird automatisch erstellt).

## Erste Einrichtung (als OP im Spiel, im Survival-Modus testen)
1. `/setspawn <Radius>` auf der Spawn-Insel – Schutzbereich (kein PvP/Schaden/Bauen). Unterhalb der Insel endet er (`spawn.protect-below`).
2. `/event setspawn <Radius>` in der Event-Arena.
3. `/airdrop setarea <Radius>` – stell dich in die Kampf-Etage. Test: `/airdrop now`.
4. `/hologram set kills` (auch `streak`, `deaths`, `kd`) am Spawn.
5. `/arena setspawn [Schutzradius] [Gebietsradius]` in der Arena (Enderperlen sind dort verboten).
6. Weitere Zonen: `/region pos1`, `/region pos2`, `/region create <Name>`, `/region flag <Name> pvp deny`.
6. `config.yml`: Discord-Webhook, `/discord`-, `/vote`-, `/website`-Links eintragen. Danach `/setrank reload`.
7. Rang vergeben: `/setrank <Spieler> <Rang> [30d|90d|perm]`.

## Wichtig zum Testen
- Zwei Accounts mit gleicher IP (selber PC/Netzwerk): Kills zählen nicht. Zum Testen `antifarm.same-ip: false` setzen.
- Creative/Spectator sind vom Instant-Tod ausgenommen.
- Alle Einstellungen und Texte stehen in der `config.yml` (15 nummerierte Abschnitte).
