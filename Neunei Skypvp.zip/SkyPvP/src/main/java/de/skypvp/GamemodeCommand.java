package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /gm0 /gm1 /gm2 /gm3  oder  /gm <0-3|s|c|a|sp> [Spieler] */
public class GamemodeCommand implements CommandExecutor, TabCompleter {

    private final SkyPvPPlugin plugin;

    public GamemodeCommand(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    private static GameMode parse(String s) {
        return switch (s.toLowerCase(Locale.ROOT)) {
            case "0", "s", "survival", "überleben" -> GameMode.SURVIVAL;
            case "1", "c", "creative", "kreativ" -> GameMode.CREATIVE;
            case "2", "a", "adventure", "abenteuer" -> GameMode.ADVENTURE;
            case "3", "sp", "spectator", "zuschauer" -> GameMode.SPECTATOR;
            default -> null;
        };
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        GameMode mode;
        int idx;
        if (name.equals("gm")) {
            mode = args.length > 0 ? parse(args[0]) : null;
            idx = 1;
        } else {
            mode = parse(name.substring(2));
            idx = 0;
        }
        if (mode == null) {
            sender.sendMessage(plugin.msg("usage-gm"));
            return true;
        }
        Player target;
        if (args.length > idx) {
            target = Bukkit.getPlayerExact(args[idx]);
            if (target == null) {
                sender.sendMessage(plugin.msg("player-not-found", "{player}", args[idx]));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        target.setGameMode(mode);
        String shown = switch (mode) {
            case SURVIVAL -> "Überleben";
            case CREATIVE -> "Kreativ";
            case ADVENTURE -> "Abenteuer";
            default -> "Zuschauer";
        };
        target.sendMessage(plugin.msg("gm-set", "{mode}", shown));
        if (!target.equals(sender)) sender.sendMessage(plugin.msg("gm-set-other", "{player}", target.getName(), "{mode}", shown));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        boolean gm = cmd.getName().equalsIgnoreCase("gm");
        if ((gm && args.length == 2) || (!gm && args.length == 1)) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(p.getName());
        } else if (gm && args.length == 1) {
            for (String s : List.of("0", "1", "2", "3")) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }
}
