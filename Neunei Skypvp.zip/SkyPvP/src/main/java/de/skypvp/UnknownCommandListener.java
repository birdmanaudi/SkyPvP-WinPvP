package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.command.UnknownCommandEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Schöne Meldung bei unbekannten Befehlen inkl. "Meintest du ...?"-Vorschlägen. */
public class UnknownCommandListener implements Listener {

    private final SkyPvPPlugin plugin;

    public UnknownCommandListener(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onUnknown(UnknownCommandEvent event) {
        String line = event.getCommandLine().trim();
        if (line.startsWith("/")) line = line.substring(1);
        String label = line.split(" ")[0].toLowerCase(Locale.ROOT);
        if (label.isEmpty()) return;

        // Befehl gibt es, aber der Spieler darf ihn nicht -> "keine Rechte" statt "gibt es nicht"
        Command existing = Bukkit.getServer().getCommandMap().getCommand(label);
        if (existing != null) {
            String np = plugin.getConfig().getString("messages.no-permission-command",
                    "&cDazu hast du keine Rechte.");
            event.message(Text.serializer().deserialize(plugin.getConfig().getString("messages.prefix", "") + np));
            return;
        }

        List<String> suggestions = suggest(event.getSender(), label);
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        String text;
        if (suggestions.isEmpty()) {
            text = plugin.getConfig().getString("messages.unknown-command",
                    "&cDen Befehl &f/{command} &cgibt es nicht.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < suggestions.size(); i++) {
                if (i > 0) sb.append("&7, ");
                sb.append("&e/").append(suggestions.get(i));
            }
            text = plugin.getConfig().getString("messages.unknown-command-suggest",
                    "&c/{command} ist kein gültiger Befehl. &7Meintest du vielleicht {suggestions}&7?");
            text = text.replace("{suggestions}", sb.toString());
        }
        text = text.replace("{command}", label);
        event.message(Text.serializer().deserialize(prefix + text));
    }

    private List<String> suggest(CommandSender sender, String label) {
        int max = label.length() <= 3 ? 1 : 2;
        Map<String, Command> known = Bukkit.getServer().getCommandMap().getKnownCommands();
        List<String> names = new ArrayList<>();
        List<Integer> dist = new ArrayList<>();
        for (Map.Entry<String, Command> e : known.entrySet()) {
            String name = e.getKey().toLowerCase(Locale.ROOT);
            if (name.contains(":") || names.contains(name)) continue;
            if (!e.getValue().testPermissionSilent(sender)) continue;
            int d = distance(label, name);
            boolean prefixMatch = label.length() >= 2 && name.startsWith(label);
            if (d <= max || prefixMatch) {
                names.add(name);
                dist.add(prefixMatch ? Math.min(d, 1) : d);
            }
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        order.sort(Comparator.comparingInt((Integer i) -> dist.get(i)).thenComparing(i -> names.get(i)));
        List<String> out = new ArrayList<>();
        for (int i : order) {
            out.add(names.get(i));
            if (out.size() >= 3) break;
        }
        return out;
    }

    private static int distance(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }
}
