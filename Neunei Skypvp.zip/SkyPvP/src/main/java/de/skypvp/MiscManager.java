package de.skypvp;

import io.papermc.paper.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.world.EntitiesLoadEvent;

/**
 * Kleinkram (Abschnitt "misc" in der config.yml): keine Mobs, kein Hunger, keine Todes-/Erfolgs-Meldungen,
 * Items bleiben liegen, bis der Item-Cleaner kommt.
 */
public class MiscManager implements Listener {

    private final SkyPvPPlugin plugin;

    public MiscManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTask(plugin, this::removeAllMobs);
    }

    private boolean flag(String key) {
        return plugin.getConfig().getBoolean("misc." + key, true);
    }

    private void removeAllMobs() {
        if (!flag("no-mobs")) return;
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e instanceof Mob) e.remove();
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (flag("no-mobs") && e.getEntity() instanceof Mob) e.setCancelled(true);
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        if (!flag("no-mobs")) return;
        for (Entity en : e.getEntities()) {
            if (en instanceof Mob) en.remove();
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onFood(FoodLevelChangeEvent e) {
        if (flag("no-hunger") && e.getEntity() instanceof Player p) {
            e.setCancelled(true);
            p.setFoodLevel(20);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (flag("no-hunger")) {
            e.getPlayer().setFoodLevel(20);
            e.getPlayer().setSaturation(20f);
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (flag("no-hunger")) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                e.getPlayer().setFoodLevel(20);
                e.getPlayer().setSaturation(20f);
            });
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        if (flag("no-death-messages")) e.deathMessage(null);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onAdvancement(PlayerAdvancementDoneEvent e) {
        if (flag("no-advancement-messages")) e.message(null);
    }

    /** Gedroppte Items verschwinden nicht von selbst, sondern erst beim Item-Cleaner. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onItem(ItemSpawnEvent e) {
        if (!flag("items-stay-until-cleaner")) return;
        Item item = e.getEntity();
        item.setUnlimitedLifetime(true);
    }
}
