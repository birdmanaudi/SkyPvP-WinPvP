package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.List;

/**
 * /rl  – Server-Neustart mit Countdown (Abschnitt "reload" in der config.yml).
 *   /rl          startet den Countdown (Standard 60 s, die letzten 15 s groß im Bild)
 *   /rl cancel   bricht ab
 *   /rl now      ohne Countdown
 */
public class ReloadManager implements CommandExecutor {

    private final SkyPvPPlugin plugin;
    private BukkitTask task;
    private int left;

    public ReloadManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase();
        if (sub.equals("cancel") || sub.equals("stop") || sub.equals("abbrechen")) {
            if (task == null) {
                sender.sendMessage(plugin.msg("reload-none"));
                return true;
            }
            task.cancel();
            task = null;
            Bukkit.broadcast(plugin.msg("reload-cancelled"));
            return true;
        }
        if (task != null) {
            sender.sendMessage(plugin.msg("reload-already", "{seconds}", String.valueOf(left)));
            return true;
        }
        if (sub.equals("now") || sub.equals("sofort")) {
            execute();
            return true;
        }
        left = Math.max(1, plugin.getConfig().getInt("reload.countdown", 60));
        Bukkit.broadcast(plugin.msg("reload-start", "{seconds}", String.valueOf(left)));
        List<Integer> announce = plugin.getConfig().getIntegerList("reload.announce-at");
        int bigFrom = plugin.getConfig().getInt("reload.big-from", 15);
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            left--;
            if (left <= 0) {
                task.cancel();
                task = null;
                execute();
                return;
            }
            if (left <= bigFrom) {
                Title t = Title.title(Text.legacy(plugin.getConfig().getString("reload.title", "&c&l{seconds}")
                                .replace("{seconds}", String.valueOf(left))),
                        Text.legacy(plugin.getConfig().getString("reload.subtitle", "&7Server startet neu")),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO));
                for (Player p : Bukkit.getOnlinePlayers()) p.showTitle(t);
            }
            if (announce.contains(left) || left == bigFrom) {
                Bukkit.broadcast(plugin.msg("reload-countdown", "{seconds}", String.valueOf(left)));
            }
        }, 20L, 20L);
        return true;
    }

    private void execute() {
        String mode = plugin.getConfig().getString("reload.mode", "restart").toLowerCase();
        if (mode.equals("reload")) {
            plugin.reloadConfig();
            plugin.ranks().loadRanks();
            for (Player p : Bukkit.getOnlinePlayers()) plugin.ranks().apply(p);
            plugin.sidebar().reloadAll();
            plugin.chat().reload();
            plugin.holograms().refreshAll();
            Bukkit.broadcast(plugin.msg("reloaded"));
            return;
        }
        Component kick = Text.legacy(plugin.getConfig().getString("reload.kick-message",
                "&#FFB800&lWin&#E03A1E&lPvP&7.de\n&7Server startet neu - gleich wieder da!").replace("\\n", "\n"));
        for (Player p : Bukkit.getOnlinePlayers()) p.kick(kick);
        if (mode.equals("stop")) {
            Bukkit.shutdown();
        } else {
            Bukkit.spigot().restart();
        }
    }
}
