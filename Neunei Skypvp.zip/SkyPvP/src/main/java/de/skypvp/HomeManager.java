package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.io.File;
import java.io.IOException;

/**
 * /sethome und /home – persönlicher Spawn (Recht skypvp.home, ab Rang 2).
 * Gesperrt im Kampf, in der Arena und beim Event.
 */
public class HomeManager implements CommandExecutor, Listener {

    private final SkyPvPPlugin plugin;
    private final File file;
    private final YamlConfiguration data;

    public HomeManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "homes.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    private Location get(Player p) {
        String b = "homes." + p.getUniqueId();
        World w = Bukkit.getWorld(data.getString(b + ".world", ""));
        if (w == null) return null;
        return new Location(w, data.getDouble(b + ".x"), data.getDouble(b + ".y"), data.getDouble(b + ".z"),
                (float) data.getDouble(b + ".yaw"), (float) data.getDouble(b + ".pitch"));
    }

    private boolean blocked(Player p) {
        if (plugin.combat().isInCombat(p)) return true;
        Location l = p.getLocation();
        if (plugin.arena() != null && plugin.arena().isInPearlZone(l)) return true;
        EventManager ev = plugin.events();
        return ev != null && (ev.isParticipant(p.getUniqueId()) || ev.isInPearlZone(l));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (blocked(p)) {
            p.sendMessage(plugin.msg("home-blocked"));
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("sethome")) {
            String b = "homes." + p.getUniqueId();
            Location l = p.getLocation();
            data.set(b + ".world", l.getWorld().getName());
            data.set(b + ".x", l.getX());
            data.set(b + ".y", l.getY());
            data.set(b + ".z", l.getZ());
            data.set(b + ".yaw", l.getYaw());
            data.set(b + ".pitch", l.getPitch());
            try {
                data.save(file);
            } catch (IOException ex) {
                plugin.getLogger().warning("homes.yml konnte nicht gespeichert werden: " + ex.getMessage());
            }
            p.sendMessage(plugin.msg("home-set"));
            return true;
        }
        Location home = get(p);
        if (home == null) {
            p.sendMessage(plugin.msg("home-none"));
            return true;
        }
        int delay = p.hasPermission("skypvp.spawn.instant") ? 0 : plugin.getConfig().getInt("home.teleport-delay", 3);
        if (delay <= 0) {
            p.teleport(home);
            return true;
        }
        Location start = p.getLocation().getBlock().getLocation();
        p.sendMessage(plugin.msg("home-teleport", "{seconds}", String.valueOf(delay)));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            if (!p.getLocation().getBlock().getLocation().equals(start) || blocked(p)) {
                p.sendMessage(plugin.msg("spawn-cancelled"));
                return;
            }
            p.teleport(home);
        }, delay * 20L);
        return true;
    }

    /** Nach dem Tod am eigenen Home statt am Spawn erscheinen (home.respawn-at-home). */
    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent e) {
        if (!plugin.getConfig().getBoolean("home.respawn-at-home", true)) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("skypvp.home")) return;
        Location home = get(p);
        if (home != null) e.setRespawnLocation(home);
    }
}
