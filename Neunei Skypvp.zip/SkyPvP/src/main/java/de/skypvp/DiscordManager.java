package de.skypvp;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Schickt Meldungen per Webhook in einen Discord-Kanal (discord.* in der config.yml). */
public class DiscordManager {

    public static final int RED = 0xE03A1E;
    public static final int GOLD = 0xFFB800;
    public static final int GREEN = 0x3BA55D;
    public static final int GRAY = 0x99AAB5;

    private final SkyPvPPlugin plugin;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    public DiscordManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    /** type = report, punish, event, maintenance, antifarm (einzeln abschaltbar unter discord.events). */
    public void send(String type, String title, String description, int color) {
        if (!plugin.getConfig().getBoolean("discord.events." + type, true)) return;
        // Kanal wählen: discord.channels.<typ> -> discord.webhooks.<kanal> (sonst webhook-url)
        String channel = plugin.getConfig().getString("discord.channels." + type, type.equals("event") ? "events" : "team");
        String url = plugin.getConfig().getString("discord.webhooks." + channel, "");
        if (url == null || url.isBlank()) url = plugin.getConfig().getString("discord.webhook-url", "");
        if (url == null || url.isBlank()) return;

        String json = "{\"username\":\"" + esc(plugin.getConfig().getString("discord.name", "WinPvP.de")) + "\","
                + "\"embeds\":[{\"title\":\"" + esc(title) + "\",\"description\":\"" + esc(description)
                + "\",\"color\":" + color + "}]}";
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url.trim()))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(10))
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            client.sendAsync(req, HttpResponse.BodyHandlers.discarding()).exceptionally(ex -> {
                plugin.getLogger().warning("Discord-Webhook fehlgeschlagen: " + ex.getMessage());
                return null;
            });
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("discord.webhook-url ist ungültig.");
        }
    }

    private static String esc(String in) {
        String s = in.replaceAll("(?i)[&§][0-9a-fk-or]", "");
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c);
                }
            }
        }
        return sb.toString();
    }
}
