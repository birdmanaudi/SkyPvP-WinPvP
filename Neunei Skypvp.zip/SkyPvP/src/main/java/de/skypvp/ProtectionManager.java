package de.skypvp;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingPlaceEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Bau-Schutz für die ganze Map (Abschnitt "protection" in der config.yml):
 * Spieler ohne das Recht skypvp.build können nichts abbauen, bauen, Eimer leeren, Rahmen/Rüstungsständer
 * verändern. Dazu: keine Explosions-Schäden, kein Feuer, kein Zertrampeln von Farmland.
 * Ausnahmen: Welten in "excluded-worlds" und Regionen mit dem Flag  /region flag <Name> build allow
 */
public class ProtectionManager implements Listener {

    private final SkyPvPPlugin plugin;
    private final Map<UUID, Long> lastMessage = new HashMap<>();

    public ProtectionManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean on() {
        return plugin.getConfig().getBoolean("protection.enabled", true);
    }

    private boolean flag(String key) {
        return plugin.getConfig().getBoolean("protection." + key, true);
    }

    private boolean protectedWorld(World w) {
        return w != null && !plugin.getConfig().getStringList("protection.excluded-worlds").contains(w.getName());
    }

    /** Schilder dürfen alle mit dem Recht skypvp.shop.create setzen/abbauen (Shop- und Free-Schilder). */
    private boolean signException(Player p, Material m) {
        return p != null && Tag.ALL_SIGNS.isTagged(m) && p.hasPermission("skypvp.shop.create");
    }

    /** true = der Spieler darf an dieser Stelle bauen/abbauen. */
    private boolean mayBuild(Player p, Location l) {
        if (!on() || l == null || !protectedWorld(l.getWorld())) return true;
        if (p != null && p.hasPermission("skypvp.build")) return true;
        RegionManager r = plugin.regions();
        return r != null && r.explicitlyAllows(l, "build") && !r.denies(l, "build");
    }

    private void deny(Player p) {
        long now = System.currentTimeMillis();
        Long last = lastMessage.get(p.getUniqueId());
        if (last != null && now - last < 2000) return;
        lastMessage.put(p.getUniqueId(), now);
        String text = plugin.getConfig().getString("messages.build-denied", "&cHier darfst du nichts bauen oder abbauen.");
        p.sendMessage(Text.legacy(plugin.getConfig().getString("messages.prefix", "") + text));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        lastMessage.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ Bauen / Abbauen

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!flag("block-break")) return;
        if (signException(e.getPlayer(), e.getBlock().getType())) return;
        if (!mayBuild(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!flag("block-place")) return;
        if (signException(e.getPlayer(), e.getBlockPlaced().getType())) return;
        if (!mayBuild(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (!flag("buckets")) return;
        if (!mayBuild(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (!flag("buckets")) return;
        if (!mayBuild(e.getPlayer(), e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    // ------------------------------------------------------------------ Rahmen, Gemälde, Rüstungsständer

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingPlace(HangingPlaceEvent e) {
        Player p = e.getPlayer();
        if (p == null || !flag("armorstands")) return;
        if (!mayBuild(p, e.getEntity().getLocation())) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakEvent e) {
        if (!on() || !protectedWorld(e.getEntity().getWorld())) return;
        if (e.getCause() == HangingBreakEvent.RemoveCause.EXPLOSION && flag("explosions")) {
            e.setCancelled(true);
            return;
        }
        if (e instanceof HangingBreakByEntityEvent byEntity && flag("armorstands")) {
            Player p = CombatManager.attacker(byEntity.getRemover());
            if (p != null && !mayBuild(p, e.getEntity().getLocation())) {
                e.setCancelled(true);
                deny(p);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArmorStand(PlayerArmorStandManipulateEvent e) {
        if (!flag("armorstands")) return;
        if (!mayBuild(e.getPlayer(), e.getRightClicked().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onItemFrame(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof ItemFrame) || !flag("armorstands")) return;
        if (!mayBuild(e.getPlayer(), e.getRightClicked().getLocation())) {
            e.setCancelled(true);
            deny(e.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHitDecoration(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof ArmorStand) && !(e.getEntity() instanceof Hanging)) return;
        if (!flag("armorstands")) return;
        Player p = CombatManager.attacker(e.getDamager());
        if (p != null && !mayBuild(p, e.getEntity().getLocation())) {
            e.setCancelled(true);
            deny(p);
        }
    }

    // ------------------------------------------------------------------ Explosionen, Feuer, Farmland

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (on() && flag("explosions") && protectedWorld(e.getLocation().getWorld())) e.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (on() && flag("explosions") && protectedWorld(e.getBlock().getWorld())) e.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (on() && flag("fire") && protectedWorld(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        Player p = e.getPlayer();
        if (p != null) {
            if (!mayBuild(p, e.getBlock().getLocation())) {
                e.setCancelled(true);
                deny(p);
            }
            return;
        }
        if (on() && flag("fire") && protectedWorld(e.getBlock().getWorld())) e.setCancelled(true);
    }

    /** Hacken, Äxte, Schaufeln, Knochenmehl usw. verändern auch Blöcke -> ebenfalls gesperrt. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onToolUse(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getItem() == null || e.getClickedBlock() == null) return;
        String n = e.getItem().getType().name();
        if (!(n.endsWith("_HOE") || n.endsWith("_AXE") || n.endsWith("_SHOVEL") || n.equals("BONE_MEAL")
                || n.equals("SHEARS") || n.endsWith("_DYE") || n.equals("GLOW_INK_SAC") || n.equals("INK_SAC")
                || n.equals("HONEYCOMB"))) return;
        if (!flag("block-place")) return;
        if (!mayBuild(e.getPlayer(), e.getClickedBlock().getLocation())) {
            e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
        }
    }

    /** Blöcke, die von selbst fallen / von Mobs verändert werden, und Laub-Zerfall. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityChange(org.bukkit.event.entity.EntityChangeBlockEvent e) {
        if (e.getEntity() instanceof Player) return;
        if (on() && flag("explosions") && protectedWorld(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onLeaves(org.bukkit.event.block.LeavesDecayEvent e) {
        if (on() && flag("block-break") && protectedWorld(e.getBlock().getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onFarmland(PlayerInteractEvent e) {
        if (e.getAction() != Action.PHYSICAL || e.getClickedBlock() == null) return;
        if (e.getClickedBlock().getType() != Material.FARMLAND || !flag("farmland")) return;
        if (!mayBuild(e.getPlayer(), e.getClickedBlock().getLocation())) e.setCancelled(true);
    }
}
