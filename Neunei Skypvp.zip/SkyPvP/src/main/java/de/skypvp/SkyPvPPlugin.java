package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class SkyPvPPlugin extends JavaPlugin {

    private RankManager rankManager;
    private EnderChestManager enderChestManager;
    private CombatManager combatManager;
    private SpawnManager spawnManager;
    private StatsManager statsManager;
    private SidebarManager sidebarManager;
    private ChatManager chatManager;
    private HistoryManager historyManager;
    private StaffManager staffManager;
    private EventManager eventManager;
    private ItemCleaner itemCleaner;
    private WhitelistManager whitelistManager;
    private KitManager kitManager;
    private DiscordManager discordManager;
    private RegionManager regionManager;
    private InfoManager infoManager;
    private BrandingManager brandingManager;
    private AirdropManager airdropManager;
    private TrophyManager trophyManager;
    private HologramManager hologramManager;
    private ArenaManager arenaManager;
    private OldPvPManager oldPvPManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        rankManager = new RankManager(this);
        discordManager = new DiscordManager(this);
        historyManager = new HistoryManager(this);
        statsManager = new StatsManager(this);
        enderChestManager = new EnderChestManager(this);
        spawnManager = new SpawnManager(this);
        combatManager = new CombatManager(this);
        chatManager = new ChatManager(this);
        sidebarManager = new SidebarManager(this);
        staffManager = new StaffManager(this);
        eventManager = new EventManager(this);
        itemCleaner = new ItemCleaner(this);
        whitelistManager = new WhitelistManager(this);
        regionManager = new RegionManager(this);
        infoManager = new InfoManager(this);
        brandingManager = new BrandingManager(this);
        airdropManager = new AirdropManager(this);
        trophyManager = new TrophyManager(this);
        hologramManager = new HologramManager(this);
        arenaManager = new ArenaManager(this);
        oldPvPManager = new OldPvPManager(this);
        HelpManager help = new HelpManager(this);
        PunishManager punish = new PunishManager(this);
        ReportManager reports = new ReportManager(this);
        kitManager = new KitManager(this);
        KitManager kits = kitManager;
        MessageManager messages = new MessageManager(this);
        SetRankCommand setRank = new SetRankCommand(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new KillListener(this), this);
        pm.registerEvents(new ShopListener(this), this);
        pm.registerEvents(enderChestManager, this);
        pm.registerEvents(spawnManager, this);
        pm.registerEvents(combatManager, this);
        pm.registerEvents(punish, this);
        pm.registerEvents(staffManager, this);
        pm.registerEvents(chatManager, this);
        pm.registerEvents(new InstantDeathListener(this), this);
        pm.registerEvents(eventManager, this);
        pm.registerEvents(whitelistManager, this);
        pm.registerEvents(regionManager, this);
        pm.registerEvents(infoManager, this);
        pm.registerEvents(brandingManager, this);
        pm.registerEvents(airdropManager, this);
        pm.registerEvents(new UnknownCommandListener(this), this);
        pm.registerEvents(help, this);
        pm.registerEvents(new PingManager(this), this);
        pm.registerEvents(new PearlManager(this), this);
        pm.registerEvents(new ProtectionManager(this), this);
        pm.registerEvents(oldPvPManager, this);
        pm.registerEvents(new MiscManager(this), this);
        HomeManager homes = new HomeManager(this);
        pm.registerEvents(homes, this);
        ReloadManager reload = new ReloadManager(this);
        GamemodeCommand gamemode = new GamemodeCommand(this);

        register("setrank", setRank, setRank);
        register("enderchest", enderChestManager, null);
        register("kit", kits, kits);
        register("kick", punish, punish);
        register("ban", punish, punish);
        register("tempban", punish, punish);
        register("unban", punish, punish);
        register("mute", chatManager, chatManager);
        register("chatmute", chatManager, null);
        register("hilfe", help, null);
        register("arena", arenaManager, arenaManager);
        register("unmute", chatManager, chatManager);
        register("history", historyManager, historyManager);
        register("report", reports, null);
        register("reports", reports, null);
        register("fly", staffManager, null);
        register("vanish", staffManager, null);
        register("setspawn", spawnManager, null);
        register("spawn", spawnManager, null);
        register("msg", messages, null);
        register("reply", messages, null);
        register("stats", statsManager, statsManager);
        register("top", statsManager, statsManager);
        register("event", eventManager, eventManager);
        register("clearitems", itemCleaner, null);
        register("whitelist", whitelistManager, whitelistManager);
        register("region", regionManager, regionManager);
        for (String name : new String[]{"regeln", "discord", "vote", "website", "votereward", "creator"}) {
            register(name, infoManager, null);
        }
        register("trophy", trophyManager, trophyManager);
        register("airdrop", airdropManager, airdropManager);
        register("hologram", hologramManager, hologramManager);
        register("rl", reload, null);
        register("team", new TeamCommand(this), null);
        register("sethome", homes, null);
        register("home", homes, null);
        for (String gm : new String[]{"gm", "gm0", "gm1", "gm2", "gm3"}) register(gm, gamemode, gamemode);

        // abgelaufene befristete Ränge jede Minute prüfen
        Bukkit.getScheduler().runTaskTimer(this, rankManager::checkExpiry, 1200L, 1200L);

        // /reload-sicher: bereits online Spieler direkt versorgen
        for (Player p : Bukkit.getOnlinePlayers()) {
            rankManager.apply(p);
            sidebarManager.attach(p);
        }
    }

    private void register(String name, CommandExecutor executor, TabCompleter completer) {
        PluginCommand cmd = getCommand(name);
        if (cmd == null) {
            getLogger().warning("Befehl fehlt in plugin.yml: " + name);
            return;
        }
        cmd.setExecutor(executor);
        if (completer != null) cmd.setTabCompleter(completer);
    }

    @Override
    public void onDisable() {
        if (enderChestManager != null) enderChestManager.saveAll();
        if (statsManager != null) statsManager.save();
        if (hologramManager != null) hologramManager.shutdown();
        if (airdropManager != null) airdropManager.cleanup();
        if (oldPvPManager != null) oldPvPManager.shutdown();
        if (rankManager != null) rankManager.shutdown();
    }

    public RankManager ranks() { return rankManager; }
    public CombatManager combat() { return combatManager; }
    public SpawnManager spawn() { return spawnManager; }
    public StatsManager stats() { return statsManager; }
    public SidebarManager sidebar() { return sidebarManager; }
    public ChatManager chat() { return chatManager; }
    public HistoryManager history() { return historyManager; }
    public StaffManager staff() { return staffManager; }
    public EventManager events() { return eventManager; }
    public KitManager kits() { return kitManager; }
    public DiscordManager discord() { return discordManager; }
    public TrophyManager trophies() { return trophyManager; }
    public HologramManager holograms() { return hologramManager; }
    public WhitelistManager whitelist() { return whitelistManager; }
    public ArenaManager arena() { return arenaManager; }
    public RegionManager regions() { return regionManager; }

    private Component legacy(String text) {
        return Text.serializer().deserialize(text);
    }

    private String fill(String text, String... r) {
        for (int i = 0; i + 1 < r.length; i += 2) text = text.replace(r[i], r[i + 1]);
        return text;
    }

    /** Nachricht aus der config.yml (messages.*) MIT Prefix und Platzhaltern, z. B. msg("rank-set", "{player}", "Max"). */
    public Component msg(String key, String... r) {
        String text = getConfig().getString("messages." + key, "&cFehlende Nachricht: " + key);
        return legacy(getConfig().getString("messages.prefix", "") + fill(text, r));
    }

    /** Wie msg(), aber ohne Prefix. */
    public Component raw(String key, String... r) {
        return legacy(fill(getConfig().getString("messages." + key, "&cFehlende Nachricht: " + key), r));
    }

    /** Mehrzeilige Nachricht (Liste in messages.*), ohne Prefix. */
    public List<Component> msgLines(String key, String... r) {
        List<Component> out = new ArrayList<>();
        for (String line : getConfig().getStringList("messages." + key)) out.add(legacy(fill(line, r)));
        return out;
    }
}
