package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

/** /team – zeigt das Serverteam (Ränge aus team.ranks), Online = grün, Offline = grau. */
public class TeamCommand implements CommandExecutor {

    private final SkyPvPPlugin plugin;

    public TeamCommand(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        sender.sendMessage(plugin.raw("team-header"));
        for (String id : plugin.getConfig().getStringList("team.ranks")) {
            RankManager.Rank rank = plugin.ranks().byId(id);
            if (rank == null) continue;
            List<String> names = plugin.ranks().membersOf(rank.id());
            Component line = Component.text(" " + rank.displayName(), rank.color(), TextDecoration.BOLD)
                    .append(Component.text(" » ", NamedTextColor.DARK_GRAY));
            if (names.isEmpty()) {
                line = line.append(Component.text("-", NamedTextColor.GRAY));
            } else {
                for (int i = 0; i < names.size(); i++) {
                    if (i > 0) line = line.append(Component.text(", ", NamedTextColor.DARK_GRAY));
                    Player online = Bukkit.getPlayerExact(names.get(i));
                    boolean on = online != null && !plugin.staff().isVanished(online);
                    line = line.append(Component.text(names.get(i), on ? NamedTextColor.GREEN : NamedTextColor.GRAY)
                            .decoration(TextDecoration.BOLD, false));
                }
            }
            sender.sendMessage(line);
        }
        sender.sendMessage(plugin.raw("team-footer"));
        return true;
    }
}
