package de.skypvp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Quader-Regionen (auch in der Höhe!) mit Flags pvp / build / damage / enderpearl.
 *  /region pos1 | pos2           Ecken setzen (an deiner Position – Höhe zählt mit)
 *  /region create <Name>         Region aus pos1+pos2 anlegen
 *  /region flag <Name> <pvp|build|damage|enderpearl> <allow|deny>
 *  /region delete <Name> | list | info
 */
public class RegionManager implements Listener, CommandExecutor, TabCompleter {

    private static final List<String> FLAGS = List.of("pvp", "build", "damage", "enderpearl");

    private static class Region {
        String name, world;
        int x1, y1, z1, x2, y2, z2;
        final Map<String, Boolean> flags = new LinkedHashMap<>();

        boolean contains(Location l) {
            return l.getWorld() != null && l.getWorld().getName().equals(world)
                    && l.getBlockX() >= x1 && l.getBlockX() <= x2
                    && l.getBlockY() >= y1 && l.getBlockY() <= y2
                    && l.getBlockZ() >= z1 && l.getBlockZ() <= z2;
        }
    }

    private final SkyPvPPlugin plugin;
    private final File file;
    private final Map<String, Region> regions = new LinkedHashMap<>();
    private final Map<UUID, Location> pos1 = new HashMap<>();
    private final Map<UUID, Location> pos2 = new HashMap<>();

    public RegionManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "regions.yml");
        YamlConfiguration c = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = c.getConfigurationSection("regions");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(key);
                if (s == null) continue;
                Region r = new Region();
                r.name = key;
                r.world = s.getString("world", "");
                r.x1 = s.getInt("x1");
                r.y1 = s.getInt("y1");
                r.z1 = s.getInt("z1");
                r.x2 = s.getInt("x2");
                r.y2 = s.getInt("y2");
                r.z2 = s.getInt("z2");
                ConfigurationSection f = s.getConfigurationSection("flags");
                if (f != null) for (String fl : f.getKeys(false)) r.flags.put(fl, f.getBoolean(fl));
                regions.put(key, r);
            }
        }
    }

    private void save() {
        YamlConfiguration c = new YamlConfiguration();
        for (Region r : regions.values()) {
            String p = "regions." + r.name;
            c.set(p + ".world", r.world);
            c.set(p + ".x1", r.x1);
            c.set(p + ".y1", r.y1);
            c.set(p + ".z1", r.z1);
            c.set(p + ".x2", r.x2);
            c.set(p + ".y2", r.y2);
            c.set(p + ".z2", r.z2);
            for (Map.Entry<String, Boolean> e : r.flags.entrySet()) c.set(p + ".flags." + e.getKey(), e.getValue());
        }
        try {
            c.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("regions.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    /** true, wenn an dieser Stelle eine Region das Flag verbietet (deny gewinnt immer). */
    public boolean denies(Location l, String flag) {
        for (Region r : regions.values()) {
            if (r.contains(l) && !r.flags.getOrDefault(flag, true)) return true;
        }
        return false;
    }

    /** true, wenn mindestens eine Region hier das Flag ausdrücklich erlaubt (allow). */
    public boolean explicitlyAllows(Location l, String flag) {
        for (Region r : regions.values()) {
            if (r.contains(l) && r.flags.getOrDefault(flag, false)) return true;
        }
        return false;
    }

    private static String fmt(Location l) {
        return l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }

    private static String flagText(Map<String, Boolean> flags) {
        StringBuilder sb = new StringBuilder();
        for (String f : FLAGS) {
            if (sb.length() > 0) sb.append("&8, ");
            sb.append("&7").append(f).append("=").append(flags.getOrDefault(f, true) ? "&aallow" : "&cdeny");
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (args.length == 0) {
            p.sendMessage(plugin.msg("usage-region"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "pos1" -> {
                Location l = p.getLocation().getBlock().getLocation();
                pos1.put(p.getUniqueId(), l);
                p.sendMessage(plugin.msg("region-pos", "{n}", "1", "{pos}", fmt(l)));
            }
            case "pos2" -> {
                Location l = p.getLocation().getBlock().getLocation();
                pos2.put(p.getUniqueId(), l);
                p.sendMessage(plugin.msg("region-pos", "{n}", "2", "{pos}", fmt(l)));
            }
            case "create" -> {
                if (args.length != 2 || !args[1].matches("(?i)[a-z0-9_\\-]+")) {
                    p.sendMessage(plugin.msg("usage-region"));
                    return true;
                }
                String name = args[1].toLowerCase(Locale.ROOT);
                Location a = pos1.get(p.getUniqueId());
                Location b = pos2.get(p.getUniqueId());
                if (a == null || b == null) {
                    p.sendMessage(plugin.msg("region-need-pos"));
                    return true;
                }
                if (!a.getWorld().equals(b.getWorld())) {
                    p.sendMessage(plugin.msg("region-diff-world"));
                    return true;
                }
                if (regions.containsKey(name)) {
                    p.sendMessage(plugin.msg("region-exists", "{name}", name));
                    return true;
                }
                Region r = new Region();
                r.name = name;
                r.world = a.getWorld().getName();
                r.x1 = Math.min(a.getBlockX(), b.getBlockX());
                r.y1 = Math.min(a.getBlockY(), b.getBlockY());
                r.z1 = Math.min(a.getBlockZ(), b.getBlockZ());
                r.x2 = Math.max(a.getBlockX(), b.getBlockX());
                r.y2 = Math.max(a.getBlockY(), b.getBlockY());
                r.z2 = Math.max(a.getBlockZ(), b.getBlockZ());
                for (String f : FLAGS) {
                    String v = plugin.getConfig().getString("region.default-flags." + f, (f.equals("damage") || f.equals("enderpearl")) ? "allow" : "deny");
                    r.flags.put(f, !v.equalsIgnoreCase("deny"));
                }
                regions.put(name, r);
                save();
                p.sendMessage(plugin.msg("region-created", "{name}", name, "{flags}", flagText(r.flags)));
            }
            case "delete" -> {
                if (args.length != 2 || regions.remove(args[1].toLowerCase(Locale.ROOT)) == null) {
                    p.sendMessage(plugin.msg("region-unknown", "{name}", args.length > 1 ? args[1] : "?"));
                    return true;
                }
                save();
                p.sendMessage(plugin.msg("region-deleted", "{name}", args[1].toLowerCase(Locale.ROOT)));
            }
            case "flag" -> {
                if (args.length != 4) {
                    p.sendMessage(plugin.msg("usage-region"));
                    return true;
                }
                Region r = regions.get(args[1].toLowerCase(Locale.ROOT));
                String flag = args[2].toLowerCase(Locale.ROOT);
                String val = args[3].toLowerCase(Locale.ROOT);
                if (r == null) {
                    p.sendMessage(plugin.msg("region-unknown", "{name}", args[1]));
                    return true;
                }
                if (!FLAGS.contains(flag) || !(val.equals("allow") || val.equals("deny"))) {
                    p.sendMessage(plugin.msg("region-flag-invalid"));
                    return true;
                }
                r.flags.put(flag, val.equals("allow"));
                save();
                p.sendMessage(plugin.msg("region-flag-set", "{name}", r.name, "{flags}", flagText(r.flags)));
            }
            case "list" -> {
                if (regions.isEmpty()) {
                    p.sendMessage(plugin.msg("region-none"));
                } else {
                    p.sendMessage(plugin.msg("region-list", "{regions}", String.join("&7, &f", regions.keySet())));
                }
            }
            case "info" -> {
                boolean any = false;
                for (Region r : regions.values()) {
                    if (r.contains(p.getLocation())) {
                        any = true;
                        p.sendMessage(plugin.msg("region-info", "{name}", r.name, "{flags}", flagText(r.flags)));
                    }
                }
                if (!any) p.sendMessage(plugin.msg("region-info-none"));
            }
            default -> p.sendMessage(plugin.msg("usage-region"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String start = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            for (String s : List.of("pos1", "pos2", "create", "delete", "flag", "list", "info")) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("flag"))) {
            for (String s : regions.keySet()) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 3 && args[0].equalsIgnoreCase("flag")) {
            for (String s : FLAGS) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 4 && args[0].equalsIgnoreCase("flag")) {
            for (String s : List.of("allow", "deny")) if (s.startsWith(start)) out.add(s);
        }
        return out;
    }

    // ------------------------------------------------------------------ Schutz

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.VOID || c == EntityDamageEvent.DamageCause.KILL
                || c == EntityDamageEvent.DamageCause.SUICIDE) return;
        if (denies(p.getLocation(), "damage")) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = CombatManager.attacker(e.getDamager());
        if (attacker == null || attacker.equals(victim)) return;
        if (denies(victim.getLocation(), "pvp") || denies(attacker.getLocation(), "pvp")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (denies(e.getBlock().getLocation(), "build") && !e.getPlayer().hasPermission("skypvp.region.bypass")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (denies(e.getBlock().getLocation(), "build") && !e.getPlayer().hasPermission("skypvp.region.bypass")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (denies(e.getBlock().getLocation(), "build") && !e.getPlayer().hasPermission("skypvp.region.bypass")) {
            e.setCancelled(true);
        }
    }
}
