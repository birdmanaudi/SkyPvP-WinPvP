package de.skypvp;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Enderperlen sind verboten:
 *  - in der Arena (/arena setspawn ... Gebietsradius)
 *  - rund um die Event-Arena (event.pearl-radius)
 *  - in Regionen mit dem Flag enderpearl=deny:  /region flag <Name> enderpearl deny
 */
public class PearlManager implements Listener {

    private final SkyPvPPlugin plugin;

    public PearlManager(SkyPvPPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean blocked(Location l) {
        if (l == null) return false;
        if (plugin.arena() != null && plugin.arena().isInPearlZone(l)) return true;
        if (plugin.events() != null && plugin.events().isInPearlZone(l)) return true;
        return plugin.regions() != null && plugin.regions().denies(l, "enderpearl");
    }

    private boolean inCombatBlock(Player p) {
        return plugin.getConfig().getBoolean("combat.enderpearl-block", true) && plugin.combat().isInCombat(p);
    }

    /** Wurf gar nicht erst zulassen (die Perle bleibt dabei im Inventar). */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType() != Material.ENDER_PEARL) return;
        Player p = e.getPlayer();
        if (inCombatBlock(p)) {
            e.setUseItemInHand(Event.Result.DENY);
            p.sendMessage(plugin.msg("pearl-blocked-combat"));
            return;
        }
        if (!blocked(p.getLocation())) return;
        e.setUseItemInHand(Event.Result.DENY);
        p.sendMessage(plugin.msg("pearl-blocked"));
    }

    /** Sicherheitsnetz: Teleport per Perle in oder aus einer gesperrten Zone verhindern. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (e.getCause() != PlayerTeleportEvent.TeleportCause.ENDER_PEARL) return;
        if (inCombatBlock(e.getPlayer()) || blocked(e.getFrom()) || blocked(e.getTo())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(plugin.msg("pearl-blocked"));
        }
    }
}
