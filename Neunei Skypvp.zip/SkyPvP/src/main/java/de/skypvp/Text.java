package de.skypvp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.regex.Pattern;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/** Einheitliche Text-Umwandlung: &-Farbcodes UND Hex-Farben (&#FFB800). */
public final class Text {

    private static final LegacyComponentSerializer SERIALIZER =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private Text() {
    }

    public static LegacyComponentSerializer serializer() {
        return SERIALIZER;
    }

    public static Component legacy(String s) {
        return SERIALIZER.deserialize(s);
    }

    private static final Pattern URL = Pattern.compile("(?i)(https?://|www\\.|discord\\.gg/)[^\\s]+");

    /** Macht Links (https://..., www..., discord.gg/...) im Text anklickbar. */
    public static Component linkify(Component c) {
        return c.replaceText(TextReplacementConfig.builder().match(URL).replacement((r, b) -> {
            String u = r.group();
            String full = u.toLowerCase().startsWith("http") ? u : "https://" + u;
            return b.clickEvent(ClickEvent.openUrl(full))
                    .hoverEvent(HoverEvent.showText(Component.text("Klicken zum Öffnen")))
                    .decorate(TextDecoration.UNDERLINED);
        }).build());
    }
}
